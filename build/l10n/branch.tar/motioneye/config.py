# Copyright (c) 2013 Calin Crisan
# This file is part of motionEye.
#
# motionEye is free software: you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation, either version 3 of the License, or
# (at your option) any later version.
#
# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with this program.  If not, see <http://www.gnu.org/licenses/>.
from __future__ import annotations

import logging
import os.path
import tarfile
from collections import OrderedDict
from errno import EEXIST, ENOENT
from fnmatch import fnmatchcase
from glob import glob
from io import BytesIO
from os import stat
from re import match, sub
from secrets import token_hex
from shlex import split
from stat import S_IMODE
from subprocess import STDOUT
from typing import TYPE_CHECKING, Literal, cast, overload
from urllib.parse import quote, urlunparse

if TYPE_CHECKING:
    from gettext import gettext as _  # noqa: TC004

from argon2 import PasswordHasher
from tornado.ioloop import IOLoop

import motioneye
from motioneye import meyectl, motionctl, settings, tasks, uploadservices, utils
from motioneye.controls import diskctl, smbctl, v4l2ctl
from motioneye.controls.powerctl import PowerControl

ph = PasswordHasher()
_CAMERA_CONFIG_FILE_NAME = 'camera-%(id)s.conf'
# the motionEye version that last saved a camera config, read by migration.py
CONFIG_VERSION_KEY = '@config_motioneye_version'
_MAIN_CONFIG_FILE_NAME = 'motion.conf'
_ACTIONS = [
    'lock',
    'unlock',
    'light_on',
    'light_off',
    'alarm_on',
    'alarm_off',
    'up',
    'right',
    'down',
    'left',
    'zoom_in',
    'zoom_out',
    'preset1',
    'preset2',
    'preset3',
    'preset4',
    'preset5',
    'preset6',
    'preset7',
    'preset8',
    'preset9',
]

_main_config_cache: dict | None = None
_camera_config_cache: dict = {}
_camera_ids_cache: list | None = None
_monitor_command_cache: dict = {}

_USED_MOTION_OPTIONS = {
    'auto_brightness',
    'despeckle_filter',
    'camera_name',
    'emulate_motion',
    'event_gap',
    'framerate',
    'height',
    'lightswitch_percent',
    'locate_motion_mode',
    'locate_motion_style',
    'mask_file',
    'mask_privacy',
    'movie_codec',
    'movie_filename',
    'movie_max_time',
    'movie_output_motion',
    'movie_output',
    'movie_quality',
    'movie_passthrough',
    'minimum_motion_frames',
    'mmalcam_name',
    'netcam_keepalive',
    'netcam_tolerant_check',
    'netcam_url',
    'netcam_use_tcp',
    'netcam_userpass',
    'noise_level',
    'noise_tune',
    'on_event_end',
    'on_event_start',
    'on_movie_end',
    'on_picture_save',
    'pause',
    'picture_filename',
    'picture_output_motion',
    'picture_output',
    'picture_quality',
    'post_capture',
    'pre_capture',
    'rotate',
    'smart_mask_speed',
    'snapshot_filename',
    'snapshot_interval',
    'stream_authentication',
    'stream_auth_method',
    'stream_localhost',
    'stream_maxrate',
    'stream_motion',
    'stream_port',
    'stream_quality',
    'target_dir',
    'text_changes',
    'text_scale',
    'text_left',
    'text_right',
    'threshold',
    'threshold_maximum',
    'threshold_tune',
    'videodevice',
    'vid_control_params',
    'webcontrol_auth_method',
    'webcontrol_authentication',
    'webcontrol_interface',
    'webcontrol_localhost',
    'webcontrol_parms',
    'webcontrol_port',
    'width',
}


def text_double(v: bool, data: dict) -> dict:
    return {'text_scale': [1, 2][v]}


def webcontrol_html_output(v: bool, data: dict) -> dict:
    return {'webcontrol_interface': int(v)}


def text_scale(v: int, data: dict) -> dict:
    return {'text_double': int(v) > 1}


def webcontrol_interface(v: int, data: dict) -> dict:
    return {'webcontrol_html_output': bool(v)}


_MOTION_41_TO_43_OPTIONS_MAPPING = {
    'ffmpeg_video_codec': 'movie_codec',
    'ffmpeg_output_movies': 'movie_output',
    'ffmpeg_output_debug_movies': 'movie_output_motion',
    'ffmpeg_variable_bitrate': 'movie_quality',
    'lightswitch': 'lightswitch_percent',
    'max_movie_time': 'movie_max_time',
    'output_pictures': 'picture_output',
    'output_debug_pictures': 'picture_output_motion',
    'quality': 'picture_quality',
    'rtsp_uses_tcp': 'netcam_use_tcp',
    'text_double': text_double,
    'webcontrol_html_output': webcontrol_html_output,
}


_MOTION_43_TO_41_OPTIONS_MAPPING = {
    'movie_codec': 'ffmpeg_video_codec',
    'movie_output': 'ffmpeg_output_movies',
    'movie_output_motion': 'ffmpeg_output_debug_movies',
    'movie_quality': 'ffmpeg_variable_bitrate',
    'lightswitch_percent': 'lightswitch',
    'movie_max_time': 'max_movie_time',
    'picture_output': 'output_pictures',
    'picture_output_motion': 'output_debug_pictures',
    'picture_quality': 'quality',
    'netcam_use_tcp': 'rtsp_uses_tcp',
    'text_scale': text_scale,
    'webcontrol_interface': webcontrol_interface,
    # motion pre-v4.1
    'webcontrol_parms': None,
}


def netcam_keepalive_params(v: bool | str, data: dict) -> dict:
    value: str = 'on' if v == True else 'force' if v == 'force' else 'off'

    if data.get('netcam_params'):
        return {'netcam_params': data['netcam_params'] + ',keepalive = ' + value}

    return {'netcam_params': 'keepalive = ' + value}


def netcam_tolerant_check_params(v: bool, data: dict) -> dict:
    value: str = 'on' if v else 'off'

    if data.get('netcam_params'):
        return {'netcam_params': data['netcam_params'] + ',tolerant_check = ' + value}

    return {'netcam_params': 'tolerant_check = ' + value}


def netcam_use_tcp_params(v: bool, data: dict) -> dict:
    value: str = 'tcp' if v else 'udp'

    if data.get('netcam_params'):
        return {'netcam_params': data['netcam_params'] + ',rtsp_transport = ' + value}

    return {'netcam_params': 'rtsp_transport = ' + value}


def netcam_params(v: str, data: dict) -> dict:
    params: dict = {}
    others = []
    for param in v.split(','):
        split = [x.strip() for x in param.split('=')]
        if split[0] == 'keepalive':
            params['netcam_keepalive'] = (
                True if split[1] == 'on' else 'force' if split[1] == 'force' else False
            )

        elif split[0] == 'tolerant_check':
            params['netcam_tolerant_check'] = split[1] == 'on'

        elif split[0] == 'rtsp_transport':
            params['netcam_use_tcp'] = split[1] != 'udp'

        elif split[0]:
            others.append(param)

    if others:
        params['netcam_params'] = ','.join(others).strip()

    return params


_MOTION_43_TO_44_OPTIONS_MAPPING = {
    'netcam_keepalive': netcam_keepalive_params,
    'netcam_tolerant_check': netcam_tolerant_check_params,
    'netcam_use_tcp': netcam_use_tcp_params,
    'vid_control_params': 'video_params',
    'videodevice': 'video_device',
}


_MOTION_44_TO_43_OPTIONS_MAPPING = {
    'netcam_params': netcam_params,
    'video_params': 'vid_control_params',
    'video_device': 'videodevice',
}


def adapt_config_directives(data: dict, mapping: dict) -> None:
    for name in list(data.keys()):
        mapped = mapping.get(name)
        if mapped is None:
            continue

        value = data.pop(name)

        if callable(mapped):
            data.update(mapped(value, data))

        else:  # assuming simple new name
            data[mapped] = value


@overload
def get_main(as_lines: Literal[False] = False) -> dict: ...


@overload
def get_main(as_lines: Literal[True]) -> list: ...


def get_main(as_lines: bool = False) -> dict | list:
    global _main_config_cache
    if not as_lines and _main_config_cache is not None:
        return _main_config_cache

    config_file_path = os.path.join(settings.CONF_PATH, _MAIN_CONFIG_FILE_NAME)

    logging.debug(f'reading main config from file {config_file_path} ...')

    lines = None
    try:
        f = open(config_file_path)  # noqa: SIM115

    except OSError as e:
        if e.errno == ENOENT:  # file does not exist
            logging.info(
                f'main config file {config_file_path} does not exist, using default values'
            )
            lines = []

        else:
            logging.error(f'could not open main config file {config_file_path}: {e}')
            raise

    else:
        with f:
            if S_IMODE(stat(config_file_path).st_mode) != 0o600:
                logging.warning(
                    f'main config file {config_file_path} has insecure mode, applying 0600 ...'
                )
                try:
                    os.chmod(config_file_path, 0o600)

                except Exception as e:
                    logging.error(
                        f'could not harden mode of main config file {config_file_path}: {e}'
                    )
                    raise

            try:
                lines = [line.strip() for line in f]

            except Exception as e:
                logging.error(
                    f'could not read main config file {config_file_path}: {e}'
                )
                raise

    if as_lines:
        return lines

    main_config = _conf_to_dict(
        lines,
        list_names=['camera'],
        no_convert=[
            '@admin_username',
            '@admin_password',
            '@normal_username',
            '@normal_password',
            '@relay_secret',
            '@client_secret',
        ],
    )

    # Generate relay secret if it doesn't exist (for Motion daemon relay event authentication)
    save_needed = False
    relay_secret = main_config.get('@relay_secret')
    if not relay_secret:
        logging.info('Generating new relay secret for Motion daemon authentication')
        relay_secret = token_hex(32)  # 64-character hex string
        main_config['@relay_secret'] = relay_secret
        save_needed = True

    # Generate client secret if it doesn't exist (for HMAC authentication from remote instances)
    client_secret = main_config.get('@client_secret')
    if not client_secret:
        logging.info('Generating new client secret for remote HMAC authentication')
        client_secret = token_hex(32)  # 64-character hex string
        main_config['@client_secret'] = client_secret
        save_needed = True

    if _set_motion_control_auth(main_config):
        logging.info('Applying motion control interface authentication to config file')
        save_needed = True

    if save_needed:
        logging.info('Saving migrated passwords and secrets to config file')
        # Cache must be set before calling set_main to avoid AttributeError
        _main_config_cache = main_config
        set_main(main_config)

    # adapt directives for motion versions < 4.2 and > 4.3
    adapt_config_directives(main_config, _MOTION_41_TO_43_OPTIONS_MAPPING)
    adapt_config_directives(main_config, _MOTION_44_TO_43_OPTIONS_MAPPING)

    _set_default_motion(main_config)

    _main_config_cache = main_config

    return main_config


def set_main(main_config: dict) -> None:
    global _main_config_cache

    main_config = dict(main_config)
    if _main_config_cache is not None:
        for n, v in list(_main_config_cache.items()):
            main_config.setdefault(n, v)
    _main_config_cache = main_config

    main_config = dict(main_config)

    # adapt directives for motion versions < 4.2 and > 4.3
    if motionctl.is_motion_pre42():
        adapt_config_directives(main_config, _MOTION_43_TO_41_OPTIONS_MAPPING)

    elif motionctl.is_motion_post43():
        adapt_config_directives(main_config, _MOTION_43_TO_44_OPTIONS_MAPPING)

    # read the actual configuration from file
    config_file_path: str = os.path.join(settings.CONF_PATH, _MAIN_CONFIG_FILE_NAME)
    lines: list = get_main(as_lines=True)

    # write the configuration to file
    logging.debug(f'writing main config to {config_file_path} ...')

    try:
        fd = os.open(
            config_file_path,
            os.O_WRONLY | os.O_CREAT | os.O_TRUNC,
            0o600,
        )

    except Exception as e:
        logging.error(
            f'could not open main config file {config_file_path} for writing: {e}'
        )
        raise

    try:
        f = os.fdopen(fd, 'w')

    except Exception as e:
        os.close(fd)
        logging.error(
            f'could not open descriptor of main config file {config_file_path} for writing: {e}'
        )
        raise

    with f:
        lines = _dict_to_conf(lines, main_config, list_names=['camera'])

        try:
            f.writelines([utils.make_str(line) + '\n' for line in lines])

        except Exception as e:
            logging.error(f'could not write main config file {config_file_path}: {e}')
            raise


def get_camera_ids() -> list:
    global _camera_ids_cache
    if _camera_ids_cache is not None:
        return _camera_ids_cache

    config_path = settings.CONF_PATH

    logging.debug(f'listing config dir {config_path} ...')

    try:
        ls = os.listdir(config_path)

    except Exception as e:
        logging.error(f'failed to list config dir {config_path}: {e}')
        raise

    camera_ids = []

    pattern = '^' + _CAMERA_CONFIG_FILE_NAME.replace('%(id)s', r'(\d+)') + '$'
    for name in ls:
        _match = match(pattern, name)
        if _match:
            camera_id = int(_match.groups()[0])
            logging.debug(f'found camera with id {camera_id}')

            camera_ids.append(camera_id)

    camera_ids.sort()

    filtered_camera_ids = []
    for camera_id in camera_ids:
        if get_camera(camera_id):
            filtered_camera_ids.append(camera_id)

    _camera_ids_cache = filtered_camera_ids

    return filtered_camera_ids


def get_enabled_local_motion_cameras() -> list:
    if not get_main().get('@enabled'):
        return []

    camera_ids = get_camera_ids()
    cameras = [get_camera(camera_id) for camera_id in camera_ids]
    return [c for c in cameras if c.get('@enabled') and utils.is_local_motion_camera(c)]


def get_relay_secret() -> str:
    """Get the relay event secret for Motion daemon authentication."""
    main_config = get_main()
    return main_config.get('@relay_secret', '')


def get_network_shares() -> list:
    if not get_main().get('@enabled'):
        return []

    camera_ids = get_camera_ids()
    cameras = [get_camera(camera_id) for camera_id in camera_ids]

    mounts = []
    for camera in cameras:
        if camera.get('@storage_device') != 'network-share':
            continue

        mounts.append(
            {
                'server': camera['@network_server'],
                'share': camera['@network_share_name'],
                'smb_ver': camera['@network_smb_ver'],
                'username': camera['@network_username'],
                'password': camera['@network_password'],
            }
        )

    return mounts


@overload
def get_camera(camera_id: int, as_lines: Literal[False] = False) -> dict: ...


@overload
def get_camera(camera_id: int, as_lines: Literal[True]) -> list: ...


def get_camera(camera_id: int, as_lines: bool = False) -> dict | list:
    if not as_lines and camera_id in _camera_config_cache:
        return _camera_config_cache[camera_id]

    camera_config_path = os.path.join(settings.CONF_PATH, _CAMERA_CONFIG_FILE_NAME) % {
        'id': camera_id
    }

    logging.debug(f'reading camera config from {camera_config_path} ...')

    try:
        f = open(camera_config_path)  # noqa: SIM115

    except Exception as e:
        logging.error(f'could not open camera config file: {e}')
        raise

    with f:
        if S_IMODE(stat(camera_config_path).st_mode) != 0o600:
            logging.warning(
                f'camera config file {camera_config_path} has insecure mode, applying 0600 ...'
            )
            try:
                os.chmod(camera_config_path, 0o600)

            except Exception as e:
                logging.error(
                    f'failed to chmod 0600 camera config file {camera_config_path}: {e}'
                )
                raise

        try:
            lines = [line.strip() for line in f]

        except Exception as e:
            logging.error(
                f'could not read camera config file {camera_config_path}: {e}'
            )
            raise

    if as_lines:
        return lines

    camera_config: dict = _conf_to_dict(
        lines,
        no_convert=[
            '@network_share_name',
            '@network_smb_ver',
            '@network_server',
            '@network_username',
            '@network_password',
            '@storage_device',
            '@upload_server',
            '@upload_username',
            '@upload_password',
            '@upload_endpoint_url',
            '@upload_access_key',
            '@upload_secret_key',
            '@upload_bucket',
            '@upload_sse_c_key',
            '@remote_secret',
            CONFIG_VERSION_KEY,
            *_NOTIFICATION_KEYS,
            'camera_name',
        ],
    )

    if utils.is_local_motion_camera(camera_config):
        # determine the enabled status
        main_config = get_main()
        cameras = main_config.get('camera', [])
        camera_config['@enabled'] = (
            _CAMERA_CONFIG_FILE_NAME % {'id': camera_id} in cameras
        )
        camera_config['@id'] = camera_id

        # adapt directives for motion versions < 4.2 and > 4.3
        adapt_config_directives(camera_config, _MOTION_41_TO_43_OPTIONS_MAPPING)
        adapt_config_directives(camera_config, _MOTION_44_TO_43_OPTIONS_MAPPING)

        _set_default_motion_camera(camera_id, camera_config)

    elif utils.is_remote_camera(camera_config):
        camera_config['@remote_verify'] = utils.verify_setting(
            camera_config.get('@remote_verify')
        )

    elif utils.is_simple_mjpeg_camera(camera_config):
        _set_default_simple_mjpeg_camera(camera_id, camera_config)

    else:  # incomplete configuration
        logging.warning(
            f'camera config file at {camera_config_path} is incomplete, ignoring'
        )
        return {}

    _camera_config_cache[camera_id] = dict(camera_config)

    return camera_config


def set_camera(camera_id: int, camera_config: dict) -> None:
    camera_config['@id'] = camera_id
    camera_config[CONFIG_VERSION_KEY] = motioneye.VERSION
    _camera_config_cache[camera_id] = camera_config

    camera_config = dict(camera_config)

    if utils.is_local_motion_camera(camera_config):
        # adapt directives for motion versions < 4.2 and > 4.3
        if motionctl.is_motion_pre42():
            adapt_config_directives(camera_config, _MOTION_43_TO_41_OPTIONS_MAPPING)

        elif motionctl.is_motion_post43():
            adapt_config_directives(camera_config, _MOTION_43_TO_44_OPTIONS_MAPPING)
            # use new "pause" setting to enable/disable motion detection
            camera_config['pause'] = not camera_config['@motion_detection']

        # set the enabled status in main config
        main_config: dict = get_main()
        cameras: list = main_config.setdefault('camera', [])
        config_file_name = _CAMERA_CONFIG_FILE_NAME % {'id': camera_id}
        if camera_config['@enabled'] and config_file_name not in cameras:
            cameras.append(config_file_name)

        elif not camera_config['@enabled']:
            cameras = [c for c in cameras if c != config_file_name]

        main_config['camera'] = cameras

        set_main(main_config)

    # read the actual configuration from file
    config_file_path = os.path.join(settings.CONF_PATH, _CAMERA_CONFIG_FILE_NAME) % {
        'id': camera_id
    }
    if os.path.isfile(config_file_path):
        lines = get_camera(camera_id, as_lines=True)

    else:
        lines = []

    # write the configuration to file
    logging.debug(f'writing camera config to {config_file_path} ...')

    try:
        fd = os.open(
            config_file_path,
            os.O_WRONLY | os.O_CREAT | os.O_TRUNC,
            0o600,
        )

    except Exception as e:
        logging.error(
            f'could not open camera config file {config_file_path} for writing: {e}'
        )
        raise

    try:
        f = os.fdopen(fd, 'w')

    except Exception as e:
        os.close(fd)
        logging.error(
            f'could not open descriptor of camera config file {config_file_path} for writing: {e}'
        )
        raise

    with f:
        lines = _dict_to_conf(lines, camera_config)

        try:
            f.writelines([utils.make_str(line) + '\n' for line in lines])

        except Exception as e:
            logging.error(f'could not write camera config file {config_file_path}: {e}')
            raise


# what motionEye's own on_* commands read from the camera config, by argument name
SENDMAIL_KEYS = {
    'server': '@email_notifications_smtp_server',
    'port': '@email_notifications_smtp_port',
    'account': '@email_notifications_smtp_account',
    'password': '@email_notifications_smtp_password',  # nosec: B105
    'tls': '@email_notifications_smtp_tls',
    'verify': '@email_notifications_smtp_verify',
    'sender': '@email_notifications_from',
    'to': '@email_notifications_addresses',
    'timespan': '@email_notifications_picture_time_span',
}
SENDTELEGRAM_KEYS = {
    'api': '@telegram_notifications_api',
    'chatid': '@telegram_notifications_chat_id',
    'timespan': '@telegram_notifications_picture_time_span',
}
_NOTIFICATION_KEYS = [*SENDMAIL_KEYS.values(), *SENDTELEGRAM_KEYS.values()]
_OPTIONAL_NOTIFICATION_KEYS = {SENDMAIL_KEYS['verify']}  # absent in older camera files
MOMENT = '%Y-%m-%dT%H:%M:%S'  # the event time, expanded by motion
_SHORT = f" %t '{MOMENT}'"


def get_notification_settings(camera_id: int | None, keys: dict) -> dict | None:
    camera_config = get_camera(camera_id) if camera_id is not None else None
    required = [key for key in keys.values() if key not in _OPTIONAL_NOTIFICATION_KEYS]
    if not camera_config or not all(key in camera_config for key in required):
        return None  # e.g. disabled since motion was started

    return {name: camera_config.get(key) for name, key in keys.items()}


def notification_command(data: dict, name: str, values: dict) -> str:
    # the settings go to the camera config, only what motion expands stays on its line
    for key, value in values.items():
        value = str(value).strip()  # what a '# @key value' line can keep
        if '\r' in value or '\n' in value:  # would start a new line in camera-N.conf
            raise ValueError(f'{key[1:]} must be a single line')

        data[key] = value

    return meyectl.find_command(name) + _SHORT


def _settings_to_ui(data: dict, keys: dict) -> dict:
    # typed as the UI expects them
    ui: dict = {key[1:]: str(data.get(key, '')) for key in keys.values()}
    for name, value in ui.items():
        if name.endswith('_tls'):
            ui[name] = value.lower() == 'true'

        elif name.endswith('_verify'):
            ui[name] = utils.verify_setting(value)

        elif name.endswith('_time_span'):
            ui[name] = int(value) if value.isdigit() else 0

    return ui


def make_netcam_userpass(url, raw_username, raw_password, camera_id):
    raw_username = str(raw_username)
    raw_password = str(raw_password)

    # Motion's mjpeg/mjpg/jpeg/ftp auth handling expects plain userpass here.
    if url.lower().startswith(('mjpeg', 'mjpg', 'jpeg', 'ftp')):
        userpass = f'{raw_username}:{raw_password}'
    else:
        # For other protocols, credentials go to ffmpeg as URL userinfo,
        # so reserved characters (e.g. "@", "#") must be percent-encoded.
        username = quote(raw_username, safe='')
        password = quote(raw_password, safe='')
        userpass = f'{username}:{password}'

        if username != raw_username or password != raw_password:
            logging.debug(
                f'credentials for camera {camera_id} have been percent-encoded'
            )

    return userpass


def motion_resolution_support(url: str) -> bool:
    if url.startswith(('rtsp', 'rtmp')):
        return True

    # since motion 4.4 only special prefixes mjpeg/jpeg/ftp have auto-detected resolution and are not configurable
    return motionctl.is_motion_post43() and not url.startswith(
        ('mjpeg', 'mjpg', 'jpeg', 'ftp')
    )


def add_camera(device_details: dict) -> dict:
    global _camera_ids_cache

    proto: str = device_details['proto']
    if proto in ['netcam', 'mjpeg']:
        host = device_details['host']
        if device_details['port']:
            host += ':' + str(device_details['port'])

        device_details['url'] = urlunparse(
            (device_details['scheme'], host, device_details['path'], '', '', '')
        )

    # determine the last camera id
    camera_ids: list = get_camera_ids()

    camera_id: int = 1
    while camera_id in camera_ids:
        camera_id += 1

    logging.info(f'adding new {proto} camera with id {camera_id} ...')

    # prepare a default camera config
    camera_config: dict = {'@enabled': True}
    if proto == 'v4l2':
        # find a suitable resolution
        for w, h in v4l2ctl.list_resolutions(device_details['path']):
            if w > 300:
                camera_config['width'] = w
                camera_config['height'] = h
                break

        camera_config['videodevice'] = device_details['path']

    elif proto == 'motioneye':
        camera_config['@proto'] = 'motioneye'
        camera_config['@scheme'] = device_details['scheme']
        camera_config['@host'] = device_details['host']
        camera_config['@port'] = device_details['port']
        camera_config['@path'] = device_details['path']
        try:
            camera_config['@remote_camera_id'] = int(device_details['remote_camera_id'])

        except (KeyError, TypeError, ValueError):
            raise ValueError('invalid remote camera id') from None

        if device_details.get('remote_secret'):
            camera_config['@remote_secret'] = device_details['remote_secret']

        camera_config['@remote_verify'] = utils.verify_setting(
            device_details.get('remote_verify')
        )

    elif proto == 'mmal':
        camera_config['mmalcam_name'] = device_details['path']
        camera_config['width'] = 640
        camera_config['height'] = 480

    elif proto == 'netcam':
        camera_config['netcam_url'] = device_details['url']

        if device_details['username']:
            camera_config['netcam_userpass'] = make_netcam_userpass(
                camera_config['netcam_url'],
                device_details['username'],
                device_details['password'],
                camera_id,
            )

        camera_config['netcam_keepalive'] = device_details.get('keep_alive', False)
        camera_config['netcam_tolerant_check'] = True

        if device_details.get('camera_index') == 'udp':
            camera_config['netcam_use_tcp'] = False

        if motion_resolution_support(camera_config['netcam_url']):
            camera_config['width'] = 640
            camera_config['height'] = 480

    else:  # assuming mjpeg
        camera_config['@proto'] = 'mjpeg'
        camera_config['@url'] = device_details['url']

    if utils.is_local_motion_camera(camera_config):
        _set_default_motion_camera(camera_id, camera_config)

        # go through the config conversion functions back and forth once
        camera_config = motion_camera_ui_to_dict(
            motion_camera_dict_to_ui(camera_config), camera_config
        )

    elif utils.is_simple_mjpeg_camera(camera_config):
        _set_default_simple_mjpeg_camera(camera_id, camera_config)

        # go through the config conversion functions back and forth once
        camera_config = simple_mjpeg_camera_ui_to_dict(
            simple_mjpeg_camera_dict_to_ui(camera_config), camera_config
        )

    # write the configuration to file
    set_camera(camera_id, camera_config)

    _camera_ids_cache = None
    _camera_config_cache.clear()

    camera_config = get_camera(camera_id)

    return camera_config


def rem_camera(camera_id: int) -> None:
    global _camera_ids_cache

    camera_config_name = _CAMERA_CONFIG_FILE_NAME % {'id': camera_id}
    camera_config_path = os.path.join(settings.CONF_PATH, _CAMERA_CONFIG_FILE_NAME) % {
        'id': camera_id
    }

    # remove the camera from the main config
    main_config = get_main()
    cameras = main_config.setdefault('camera', [])
    cameras = [t for t in cameras if t != camera_config_name]

    main_config['camera'] = cameras

    set_main(main_config)

    logging.info(f'removing camera config file {camera_config_path} ...')

    _camera_ids_cache = None
    _camera_config_cache.clear()

    try:
        os.remove(camera_config_path)

    except Exception as e:
        logging.error(f'could not remove camera config file {camera_config_path}: {e}')
        raise


def main_ui_to_dict(ui: dict) -> dict:
    from motioneye.handlers.base import invalidate_user_sessions

    data = {
        '@admin_username': ui['admin_username'],
        '@normal_username': ui['normal_username'],
    }

    def call_hook(u, p):
        if settings.PASSWORD_HOOK:
            env = {'MEYE_USERNAME': u, 'MEYE_PASSWORD': p}

            try:
                utils.call_subprocess(settings.PASSWORD_HOOK, env=env, stderr=STDOUT)
                logging.debug('password hook exec succeeded')

            except Exception as e:
                logging.error(f'password hook exec failed: {e}')

    if ui.get('admin_password'):  # left out or empty when unchanged
        data['@admin_password'] = ph.hash(ui['admin_password'])
        invalidate_user_sessions('admin')
        call_hook(ui['admin_username'], ui['admin_password'])

    if ui.get('normal_password'):
        data['@normal_password'] = ph.hash(ui['normal_password'])
        invalidate_user_sessions('normal')
        call_hook(ui['normal_username'], ui['normal_password'])

    if ui.get('lang') is not None:
        data['@lang'] = ui['lang']

    return data


def main_dict_to_ui(data: dict) -> dict:
    ui = {
        'admin_username': data['@admin_username'],
        'normal_username': data['@normal_username'],
    }

    if data['@lang']:
        ui['lang'] = data['@lang']

    # Only transmit an empty string if no password is set, to show an empty
    # input box in the frontend. If a password is set, transmit nothing, in
    # which case the input box will show "*****".
    if data['@admin_password'] == '':
        ui['admin_password'] = ''  # nosec: B105

    if data['@normal_password'] == '':
        ui['normal_password'] = ''  # nosec: B105

    ui['_client_secret'] = data.get('@client_secret', '')

    return ui


def _parsable(command: str, key: str, id: int) -> bool:
    try:
        split(command)

    except ValueError:
        logging.warning(
            f'camera {id} {key} command "{command}" contains invalid shell syntax'
        )
        return False

    return True


def input_sanity_check(regex: str, value: str, key: str, msg: str) -> str:
    if match(regex, value):
        return value

    else:
        raise ValueError(
            f'Value "{value}" for setting "{key}" did not match regex "{regex}": {msg}'
        )


def input_or_stored(ui: dict, key: str, prev_config: dict, default):
    # keep the stored setting if the client does not send it, e.g. in case of
    # a hub running an older release and for keys not shared, like admin-only
    return ui.get(key, prev_config.get(f'@{key}', default))


def input_required(ui, key):
    # False and 0 are set values, a missing key, None (null) or '' is not
    value = ui.get(key)
    if value is None or value == '':
        raise ValueError(f'Setting "{key}" must be set')

    return value


def _hook_verified(prev_config: dict, option: str) -> bool:
    # what the stored hook line says, for a client that does not send the key
    return '--no-verify' not in str(prev_config.get(option, ''))


def motion_camera_ui_to_dict(ui: dict, prev_config: dict | None = None) -> dict:
    prev_config = dict(prev_config or {})
    main_config = get_main()  # needed for surveillance password

    # regex definitions for input sanity checks in backend
    # they must match the ones in motioneye/static/js/main.js
    deviceNameValidRegExp = '^[A-Za-z0-9-_+ ]+$'
    deviceNameFailMessage = _(
        'Device names are only allowed to contain alphanumerical characters, hyphen -, underscore _, plus +, and space'
    )
    filenameValidRegExp = '^([A-Za-z0-9 ()/._-]|%[CYmdHMSIplqv$])+$'
    filenameFailMessage = _(
        'File names are only allowed to contain alphanumerical characters, parenthesis (), forward slash /, dot ., '
        'underscore _, hyphen -, space, and a subset of motion conversion specifiers: %C %Y %m %d %H %M %S %I %p %l %q %v %$'
    )
    dirnameValidRegExp = '^[A-Za-z0-9 ()/._-]+$'
    dirnameFailMessage = _(
        'Directory names are only allowed to contain alphanumerical characters, space, parenthesis (), forward slash /, '
        'dot ., underscore _, and hyphen -'
    )
    emailValidRegExp = '^[A-Za-z0-9 _+.@^~<>,-]+$'
    emailFailMessage = _(
        'Email addresses are only allowed to contain alphanumerical characters, underscore _, plus +, dot ., at @, '
        'caret ^, tilde ~, angle brackets <>, hyphen -, and may be separated by comma, and space'
    )
    webHookUrlValidRegExp = '^[^;\']+$'
    webHookUrlFailMessage = _(
        'URLs are not allowed to contain caret ^, semicolon ;, or apostrophe \''
    )

    data = {
        # device
        'camera_name': input_sanity_check(
            deviceNameValidRegExp, ui['name'], 'camera_name', deviceNameFailMessage
        ),
        '@enabled': ui['enabled'],
        '@admin_only': input_or_stored(ui, 'admin_only', prev_config, False),
        'auto_brightness': ui['auto_brightness'],
        'framerate': int(ui['framerate']),
        'rotate': int(ui['rotation']),
        'mask_privacy': '',
        # file storage
        '@storage_device': input_required(ui, 'storage_device'),
        '@network_server': ui['network_server'],
        '@network_share_name': ui['network_share_name'],
        '@network_smb_ver': ui['network_smb_ver'],
        '@network_username': ui['network_username'],
        '@network_password': ui['network_password'],
        '@upload_enabled': ui['upload_enabled'],
        '@upload_movie': ui['upload_movie'],
        '@upload_picture': ui['upload_picture'],
        '@upload_service': ui['upload_service'],
        '@upload_server': ui['upload_server'],
        '@upload_port': ui['upload_port'],
        '@upload_method': ui['upload_method'],
        '@upload_location': ui['upload_location'],
        '@upload_subfolders': ui['upload_subfolders'],
        '@upload_username': ui['upload_username'],
        '@upload_password': ui['upload_password'],
        '@upload_tls': input_or_stored(ui, 'upload_tls', prev_config, False),
        '@upload_verify': input_or_stored(ui, 'upload_verify', prev_config, True),
        '@upload_endpoint_url': ui['upload_endpoint_url'],
        '@upload_access_key': ui['upload_access_key'],
        '@upload_secret_key': ui['upload_secret_key'],
        '@upload_bucket': ui['upload_bucket'],
        '@upload_sse_c_key': ui['upload_sse_c_key'],
        '@clean_cloud_enabled': ui['clean_cloud_enabled'],
        '@clean_uploaded': input_or_stored(ui, 'clean_uploaded', prev_config, False),
        # text overlay
        'text_left': '',
        'text_right': '',
        'text_scale': ui['text_scale'],
        # streaming
        'stream_localhost': not ui['video_streaming'],
        'stream_port': int(ui['streaming_port']),
        'stream_maxrate': int(ui['streaming_framerate']),
        'stream_quality': max(1, int(ui['streaming_quality'])),
        '@webcam_resolution': max(1, int(ui['streaming_resolution'])),
        '@webcam_server_resize': ui['streaming_server_resize'],
        'stream_motion': ui['streaming_motion'],
        'stream_auth_method': {'disabled': 0, 'basic': 1, 'digest': 2}.get(
            ui['streaming_auth_mode'], 0
        ),
        'stream_authentication': '',
        '@lang': main_config['@lang'],
        # still images
        'picture_output': False,
        'snapshot_interval': 0,
        'picture_filename': '',
        'snapshot_filename': '',
        'picture_quality': max(1, int(ui['image_quality'])),
        '@preserve_pictures': int(ui['preserve_pictures']),
        '@manual_snapshots': ui['manual_snapshots'],
        # movies
        'movie_output': False,
        'movie_passthrough': bool(ui['movie_passthrough']),
        'movie_filename': input_sanity_check(
            filenameValidRegExp,
            ui['movie_file_name'],
            'movie_filename',
            filenameFailMessage,
        ),
        'movie_max_time': ui['max_movie_length'],
        '@preserve_movies': int(ui['preserve_movies']),
        # motion detection
        '@motion_detection': ui['motion_detection'],
        '@motion_event_button': input_or_stored(
            ui, 'motion_event_button', prev_config, False
        ),
        '@motion_detection_button': input_or_stored(
            ui, 'motion_detection_button', prev_config, False
        ),
        'emulate_motion': False,
        'text_changes': ui['show_frame_changes'],
        'locate_motion_mode': ui['show_frame_changes'],
        'threshold_maximum': ui['max_frame_change_threshold'],
        'threshold_tune': ui['auto_threshold_tuning'],
        'noise_tune': ui['auto_noise_detect'],
        'noise_level': max(1, round(int(ui['noise_level']) * 2.55)),
        'lightswitch_percent': ui['light_switch_detect'],
        'event_gap': int(ui['event_gap']),
        'pre_capture': int(ui['pre_capture']),
        'post_capture': int(ui['post_capture']),
        'minimum_motion_frames': int(ui['minimum_motion_frames']),
        'smart_mask_speed': 0,
        'mask_file': '',
        'picture_output_motion': ui['create_debug_media'],
        'movie_output_motion': ui['create_debug_media'],
        # working schedule
        '@working_schedule': '',
        # events
        'on_event_start': '',
        'on_event_end': '',
        'on_movie_end': '',
        'on_picture_save': '',
    }

    if data.get('stream_auth_method', 0) > 0:
        streaming_username = ui.get('streaming_username')
        streaming_password = ui.get('streaming_password')

        prev_stream_authentication = prev_config.get('stream_authentication')
        parts = (prev_stream_authentication or '').split(':', 1)
        prev_stream_username = parts[0]
        prev_stream_password = parts[1] if len(parts) > 1 else ''

        if not streaming_username:
            streaming_username = prev_stream_username

        # UI omits the password when unchanged.
        if not streaming_password:
            streaming_password = prev_stream_password

        # No hard fail: if still missing, keep stream_authentication empty.
        if streaming_username and streaming_password:
            data['stream_authentication'] = (
                str(streaming_username) + ':' + str(streaming_password)
            )

    if utils.is_v4l2_camera(prev_config):
        proto = 'v4l2'

    elif utils.is_mmal_camera(prev_config):
        proto = 'mmal'

    else:
        proto = 'netcam'

    if proto in ('v4l2', 'mmal'):
        # leave videodevice unchanged

        # resolution
        if not ui['resolution']:
            ui['resolution'] = '320x240'

        width = int(ui['resolution'].split('x')[0])
        height = int(ui['resolution'].split('x')[1])
        data['width'] = width
        data['height'] = height

        threshold = int(float(ui['frame_change_threshold']) * width * height / 100)

        if proto == 'v4l2':
            # video controls, control_id is the ID Motion actually matches against (see v4l2-ctl --list-ctrls)
            video_controls = v4l2ctl.list_ctrls(prev_config.get('videodevice', ''))
            if video_controls:
                vid_control_params = (
                    '{}={}'.format(
                        video_controls.get(n, {}).get('control_id', n), c['value']
                    )
                    for n, c in list(ui['video_controls'].items())
                )
                data['vid_control_params'] = ','.join(vid_control_params)

            else:
                logging.warning(
                    f'camera {prev_config["@id"]} control listing failed, '
                    'controls not updated'
                )

    else:  # assuming netcam
        if ui.get('resolution') and motion_resolution_support(
            data.get('netcam_url', prev_config.get('netcam_url', ''))
        ):
            # motion uses the configured width and height for these cameras
            width = int(ui['resolution'].split('x')[0])
            height = int(ui['resolution'].split('x')[1])
            data['width'] = width
            data['height'] = height

            threshold = int(float(ui['frame_change_threshold']) * width * height / 100)

        else:  # width & height are not available for other netcams
            threshold = int(float(ui['frame_change_threshold']) * 640 * 480 / 100)

    data['threshold'] = threshold

    if ui['privacy_mask']:
        capture_width, capture_height = data.get('width'), data.get('height')
        if data.get('rotate') in [90, 270]:
            capture_width, capture_height = capture_height, capture_width

        data['mask_privacy'] = utils.build_editable_mask_file(
            prev_config['@id'],
            'privacy',
            ui['privacy_mask_lines'],
            capture_width,
            capture_height,
        )

    data['target_dir'] = input_sanity_check(
        dirnameValidRegExp, ui['root_directory'], 'target_dir', dirnameFailMessage
    )

    if (ui['storage_device'] == 'network-share') and settings.SMB_SHARES:
        mount_point = smbctl.make_mount_point(
            ui['network_server'], ui['network_share_name'], ui['network_username']
        )
        ui['root_directory'] = ui['root_directory'].removeprefix('/')
        data['target_dir'] = os.path.normpath(
            os.path.join(mount_point, ui['root_directory'])
        )

    elif ui['storage_device'].startswith('local-disk'):
        target_dev = ui['storage_device'][10:].replace('-', '/')
        mounted_partitions = diskctl.list_mounted_partitions()
        partition = mounted_partitions.get(target_dev)
        if partition:
            mount_point = partition['mount_point']

            ui['root_directory'] = ui['root_directory'].removeprefix('/')
            data['target_dir'] = os.path.normpath(
                os.path.join(mount_point, ui['root_directory'])
            )

        else:  # not mounted, root_directory cannot be resolved against it
            data['target_dir'] = prev_config.get('target_dir', data['target_dir'])
            logging.error(
                f'could not find mounted partition for device "{target_dev}", keeping target dir "{data["target_dir"]}"'
            )

    # try to create the target dir
    try:
        os.makedirs(data['target_dir'])
        logging.debug(
            f'created root directory {data["target_dir"]} for camera {data["camera_name"]}'
        )

    except OSError as e:
        if isinstance(e, OSError) and e.errno == EEXIST:
            pass  # already exists, things should be just fine

        else:
            logging.exception(f'failed to create root directory "{data["target_dir"]}"')

    if ui['upload_enabled'] and '@id' in prev_config:
        upload_settings: dict = {
            k[7:]: ui[k] for k in list(ui.keys()) if k.startswith('upload_')
        }

        tasks.add(
            0,
            uploadservices.update,
            tag=f"uploadservices.update({ui['upload_service']})",
            camera_id=prev_config['@id'],
            service_name=ui['upload_service'],
            settings=upload_settings,
        )

    if ui['text_overlay']:
        left_text = ui['left_text']
        if left_text == 'camera-name':
            data['text_left'] = ui['name']

        elif left_text == 'timestamp':
            data['text_left'] = '%Y-%m-%d\\n%T'

        elif left_text == 'disabled':
            data['text_left'] = ''

        else:
            data['text_left'] = ui['custom_left_text']

        right_text = ui['right_text']
        if right_text == 'camera-name':
            data['text_right'] = ui['name']

        elif right_text == 'timestamp':
            data['text_right'] = '%Y-%m-%d\\n%T'

        elif right_text == 'disabled':
            data['text_right'] = ''

        else:
            data['text_right'] = ui['custom_right_text']

    if ui['still_images']:
        data['picture_filename'] = input_sanity_check(
            filenameValidRegExp,
            ui['image_file_name'],
            'picture_filename',
            filenameFailMessage,
        )
        # script aborts if above sanity check failed, hence no need to check again
        data['snapshot_filename'] = ui['image_file_name']

        capture_mode = ui['capture_mode']
        if capture_mode == 'motion-triggered':
            data['picture_output'] = True

        elif capture_mode == 'motion-triggered-one':
            data['picture_output'] = 'best'

        elif capture_mode == 'interval-snapshots':
            data['snapshot_interval'] = int(ui['snapshot_interval'])

        elif capture_mode == 'all-frames':
            data['picture_output'] = True
            data['emulate_motion'] = True

        elif capture_mode == 'manual':
            data['picture_output'] = False
            data['emulate_motion'] = False

    if ui['movies']:
        data['movie_output'] = True
        recording_mode = ui['recording_mode']
        if recording_mode == 'motion-triggered':
            data['emulate_motion'] = False

        elif recording_mode == 'continuous':
            data['emulate_motion'] = True

    data['movie_codec'] = ui['movie_format']
    q = int(ui['movie_quality'])

    data['movie_quality'] = max(1, q)

    # motion detection

    if ui['despeckle_filter']:
        data['despeckle_filter'] = prev_config['despeckle_filter'] or 'EedDl'

    else:
        data['despeckle_filter'] = ''

    if ui['motion_mask']:
        if ui['motion_mask_type'] == 'smart':
            data['smart_mask_speed'] = 11 - int(ui['smart_mask_sluggishness'])

        elif ui['motion_mask_type'] == 'editable':
            capture_width, capture_height = data.get('width'), data.get('height')
            if data.get('rotate') in [90, 270]:
                capture_width, capture_height = capture_height, capture_width

            data['mask_file'] = utils.build_editable_mask_file(
                prev_config['@id'],
                'motion',
                ui['motion_mask_lines'],
                capture_width,
                capture_height,
            )

    # working schedule
    if ui['working_schedule']:
        data['@working_schedule'] = (
            ui['monday_from']
            + '-'
            + ui['monday_to']
            + '|'
            + ui['tuesday_from']
            + '-'
            + ui['tuesday_to']
            + '|'
            + ui['wednesday_from']
            + '-'
            + ui['wednesday_to']
            + '|'
            + ui['thursday_from']
            + '-'
            + ui['thursday_to']
            + '|'
            + ui['friday_from']
            + '-'
            + ui['friday_to']
            + '|'
            + ui['saturday_from']
            + '-'
            + ui['saturday_to']
            + '|'
            + ui['sunday_from']
            + '-'
            + ui['sunday_to']
        )

        data['@working_schedule_type'] = ui['working_schedule_type']

    # event start
    on_event_start = [f"{meyectl.find_command('relayevent')} start %t"]
    # kept for a client that does not send the key
    stored_mail_verify = prev_config.get(SENDMAIL_KEYS['verify'])
    for key in _NOTIFICATION_KEYS:  # stored only while enabled
        prev_config.pop(key, None)

    if ui['email_notifications_enabled']:
        emails = sub(
            '\\s',
            '',
            input_sanity_check(
                emailValidRegExp,
                ui['email_notifications_addresses'],
                'email_notifications_addresses',
                emailFailMessage,
            ),
        )

        if ui['email_notifications_from'] != '':
            email_from = input_sanity_check(
                emailValidRegExp,
                ui['email_notifications_from'],
                'email_notifications_from',
                emailFailMessage,
            )
        else:
            email_from = ''

        values = {
            key: ui[key[1:]]
            for key in SENDMAIL_KEYS.values()
            if key != SENDMAIL_KEYS['verify']
        }
        values[SENDMAIL_KEYS['verify']] = utils.verify_setting(
            ui.get('email_notifications_smtp_verify', stored_mail_verify)
        )
        values['@email_notifications_addresses'] = emails
        values['@email_notifications_from'] = email_from
        on_event_start.append(notification_command(data, 'sendmail', values))

    if ui['telegram_notifications_enabled']:
        values = {key: ui[key[1:]] for key in SENDTELEGRAM_KEYS.values()}
        on_event_start.append(notification_command(data, 'sendtelegram', values))

    if ui['web_hook_notifications_enabled']:
        url = sub(
            '\\s',
            '+',
            input_sanity_check(
                webHookUrlValidRegExp,
                ui['web_hook_notifications_url'],
                'web_hook_notifications_url',
                webHookUrlFailMessage,
            ),
        )
        verify = utils.verify_setting(
            ui.get(
                'web_hook_notifications_verify',
                _hook_verified(prev_config, 'on_event_start'),
            )
        )

        on_event_start.append(
            "{script}{flag} '{method}' '{url}'".format(
                script=meyectl.find_command('webhook'),
                flag='' if verify else ' --no-verify',
                method=ui['web_hook_notifications_http_method'],
                url=url,
            )
        )

    if ui['command_notifications_enabled']:
        on_event_start += utils.split_semicolon(ui['command_notifications_exec'])

    data['on_event_start'] = '; '.join(on_event_start)

    # event end
    on_event_end = [f"{meyectl.find_command('relayevent')} stop %t"]

    if ui['web_hook_end_notifications_enabled']:
        url = sub(
            r'\s',
            '+',
            input_sanity_check(
                webHookUrlValidRegExp,
                ui['web_hook_end_notifications_url'],
                'web_hook_end_notifications_url',
                webHookUrlFailMessage,
            ),
        )
        verify = utils.verify_setting(
            ui.get(
                'web_hook_end_notifications_verify',
                _hook_verified(prev_config, 'on_event_end'),
            )
        )

        on_event_end.append(
            "{script}{flag} '{method}' '{url}'".format(
                script=meyectl.find_command('webhook'),
                flag='' if verify else ' --no-verify',
                method=ui['web_hook_end_notifications_http_method'],
                url=url,
            )
        )

    if ui['command_end_notifications_enabled']:
        on_event_end += utils.split_semicolon(ui['command_end_notifications_exec'])

    data['on_event_end'] = '; '.join(on_event_end)

    # movie end
    on_movie_end = [f"{meyectl.find_command('relayevent')} movie_end %t %f"]

    if ui['web_hook_storage_enabled']:
        url = sub(
            '\\s',
            '+',
            input_sanity_check(
                webHookUrlValidRegExp,
                ui['web_hook_storage_url'],
                'web_hook_storage_url',
                webHookUrlFailMessage,
            ),
        )
        verify = utils.verify_setting(
            ui.get(
                'web_hook_storage_verify', _hook_verified(prev_config, 'on_movie_end')
            )
        )

        on_movie_end.append(
            "{script}{flag} '{method}' '{url}'".format(
                script=meyectl.find_command('webhook'),
                flag='' if verify else ' --no-verify',
                method=ui['web_hook_storage_http_method'],
                url=url,
            )
        )

    if ui['command_storage_enabled']:
        on_movie_end += utils.split_semicolon(ui['command_storage_exec'])

    data['on_movie_end'] = '; '.join(on_movie_end)

    # picture save
    on_picture_save = [f"{meyectl.find_command('relayevent')} picture_save %t %f"]

    if ui['web_hook_storage_enabled']:
        url = sub(
            '\\s',
            '+',
            input_sanity_check(
                webHookUrlValidRegExp,
                ui['web_hook_storage_url'],
                'web_hook_storage_url',
                webHookUrlFailMessage,
            ),
        )
        verify = utils.verify_setting(
            ui.get(
                'web_hook_storage_verify', _hook_verified(prev_config, 'on_movie_end')
            )
        )

        on_picture_save.append(
            "{script}{flag} '{method}' '{url}'".format(
                script=meyectl.find_command('webhook'),
                flag='' if verify else ' --no-verify',
                method=ui['web_hook_storage_http_method'],
                url=url,
            )
        )

    if ui['command_storage_enabled']:
        on_picture_save += utils.split_semicolon(ui['command_storage_exec'])

    data['on_picture_save'] = '; '.join(on_picture_save)

    # extra motion options
    for name in list(prev_config.keys()):
        if name not in _USED_MOTION_OPTIONS and not name.startswith('@'):
            prev_config.pop(name)

    extra_options = ui.get('extra_options', [])
    for name, value in extra_options:
        data[name] = value or ''

    prev_config.update(data)

    return prev_config


def motion_camera_dict_to_ui(data: dict) -> dict:
    ui = {
        # device
        'name': data['camera_name'],
        'enabled': data['@enabled'],
        'id': data['@id'],
        'admin_only': data.get('@admin_only', False),
        'auto_brightness': data['auto_brightness'],
        'framerate': int(data['framerate']),
        'rotation': int(data['rotate']),
        'privacy_mask': False,
        'privacy_mask_lines': [],
        # file storage
        'smb_shares': settings.SMB_SHARES,
        'storage_device': data['@storage_device'],
        'network_server': data['@network_server'],
        'network_share_name': data['@network_share_name'],
        'network_smb_ver': data['@network_smb_ver'],
        'network_username': data['@network_username'],
        'network_password': data['@network_password'],
        'disk_used': 0,
        'disk_total': 0,
        'available_disks': diskctl.list_mounted_disks(),
        'upload_enabled': data['@upload_enabled'],
        'upload_picture': data['@upload_picture'],
        'upload_movie': data['@upload_movie'],
        'upload_service': data['@upload_service'],
        'upload_server': data['@upload_server'],
        'upload_port': data['@upload_port'],
        'upload_method': data['@upload_method'],
        'upload_location': data['@upload_location'],
        'upload_subfolders': data['@upload_subfolders'],
        'upload_username': data['@upload_username'],
        'upload_password': data['@upload_password'],
        'upload_tls': data['@upload_tls'],
        'upload_verify': data['@upload_verify'],
        'upload_authorization_key': '',  # needed, otherwise the field is hidden
        'upload_endpoint_url': data['@upload_endpoint_url'],
        'upload_access_key': data['@upload_access_key'],
        'upload_secret_key': data['@upload_secret_key'],
        'upload_bucket': data['@upload_bucket'],
        'upload_sse_c_key': data['@upload_sse_c_key'],
        'clean_cloud_enabled': data['@clean_cloud_enabled'],
        'clean_uploaded': data['@clean_uploaded'],
        'web_hook_storage_enabled': False,
        'web_hook_storage_verify': True,
        'command_storage_enabled': False,
        # text overlay
        'text_overlay': False,
        'left_text': 'camera-name',
        'right_text': 'timestamp',
        'custom_left_text': '',
        'custom_right_text': '',
        # streaming
        'video_streaming': not data['stream_localhost'],
        'streaming_framerate': int(data['stream_maxrate']),
        'streaming_quality': int(data['stream_quality']),
        'streaming_resolution': int(data['@webcam_resolution']),
        'streaming_server_resize': data['@webcam_server_resize'],
        'streaming_port': int(data['stream_port']),
        'streaming_auth_mode': {0: 'disabled', 1: 'basic', 2: 'digest'}.get(
            cast(int, data.get('stream_auth_method')), 'disabled'
        ),
        'streaming_motion': int(data['stream_motion']),
        # still images
        'still_images': False,
        'capture_mode': 'motion-triggered',
        'image_file_name': '%Y-%m-%d/%H-%M-%S',
        'image_quality': data['picture_quality'],
        'snapshot_interval': 0,
        'preserve_pictures': data['@preserve_pictures'],
        'manual_snapshots': data['@manual_snapshots'],
        # movies
        'movies': False,
        'recording_mode': 'motion-triggered',
        'movie_file_name': data['movie_filename'],
        'max_movie_length': data['movie_max_time'],
        'preserve_movies': data['@preserve_movies'],
        'movie_passthrough': data['movie_passthrough'],
        # motion detection
        'motion_detection': data['@motion_detection'],
        'motion_event_button': data['@motion_event_button'],
        'motion_detection_button': data['@motion_detection_button'],
        'show_frame_changes': data['text_changes'] or data['locate_motion_mode'],
        'auto_noise_detect': data['noise_tune'],
        'max_frame_change_threshold': data['threshold_maximum'],
        'auto_threshold_tuning': data['threshold_tune'],
        'noise_level': round(int(data['noise_level']) / 2.55),
        'light_switch_detect': data['lightswitch_percent'],
        'despeckle_filter': data['despeckle_filter'],
        'event_gap': int(data['event_gap']),
        'pre_capture': int(data['pre_capture']),
        'post_capture': int(data['post_capture']),
        'minimum_motion_frames': int(data['minimum_motion_frames']),
        'motion_mask': False,
        'motion_mask_type': 'smart',
        'smart_mask_sluggishness': 5,
        'motion_mask_lines': [],
        'create_debug_media': data['movie_output_motion']
        or data['picture_output_motion'],
        # motion notifications
        'email_notifications_enabled': False,
        'telegram_notifications_enabled': False,
        'web_hook_notifications_enabled': False,
        'web_hook_notifications_verify': True,
        'web_hook_end_notifications_enabled': False,
        'web_hook_end_notifications_verify': True,
        'command_notifications_enabled': False,
        'command_end_notifications_enabled': False,
        # working schedule
        'working_schedule': False,
        'working_schedule_type': 'during',
        'monday_from': '',
        'monday_to': '',
        'tuesday_from': '',
        'tuesday_to': '',
        'wednesday_from': '',
        'wednesday_to': '',
        'thursday_from': '',
        'thursday_to': '',
        'friday_from': '',
        'friday_to': '',
        'saturday_from': '',
        'saturday_to': '',
        'sunday_from': '',
        'sunday_to': '',
    }

    stream_authentication = data.get('stream_authentication') or ''
    streaming_username, _, streaming_password = stream_authentication.partition(':')
    ui['streaming_username'] = streaming_username
    # Only transmit an empty string if no password is set, to show an empty
    # input box in the frontend. If a password is set, transmit nothing, in
    # which case the input box will show "*****".
    if streaming_password == '':  # nosec: B105
        ui['streaming_password'] = ''  # nosec: B105

    if utils.is_net_camera(data):
        ui['device_url'] = data['netcam_url']
        ui['proto'] = 'netcam'

        # resolutions
        if motion_resolution_support(data['netcam_url']):
            # motion uses the configured width and height for these cameras
            width, height = data.get('width', 640), data.get('height', 480)
            resolutions = utils.COMMON_RESOLUTIONS
            resolutions = [r for r in resolutions if motionctl.resolution_is_valid(*r)]
            ui['available_resolutions'] = [
                (str(w) + 'x' + str(h)) for (w, h) in resolutions
            ]
            ui['resolution'] = str(width) + 'x' + str(height)

            threshold = data['threshold'] * 100.0 / (width * height)

        else:  # width & height are not available for other netcams
            # we have no other choice but use something like 640x480 as reference
            threshold = data['threshold'] * 100.0 / (640 * 480)

    elif utils.is_mmal_camera(data):
        ui['device_url'] = data['mmalcam_name']
        ui['proto'] = 'mmal'

        resolutions = utils.COMMON_RESOLUTIONS
        resolutions = [r for r in resolutions if motionctl.resolution_is_valid(*r)]
        ui['available_resolutions'] = [
            (str(w) + 'x' + str(h)) for (w, h) in resolutions
        ]
        ui['resolution'] = str(data['width']) + 'x' + str(data['height'])

        threshold = data['threshold'] * 100.0 / (data['width'] * data['height'])

    else:  # assuming v4l2
        ui['device_url'] = data['videodevice']
        ui['proto'] = 'v4l2'

        # resolutions
        resolutions = v4l2ctl.list_resolutions(data['videodevice'])
        ui['available_resolutions'] = [
            (str(w) + 'x' + str(h)) for (w, h) in resolutions
        ]
        ui['resolution'] = str(data['width']) + 'x' + str(data['height'])

        video_controls = v4l2ctl.list_ctrls(data['videodevice'])

        # video_params is keyed by control_id, map it back to our UI name
        name_by_control_id = {
            c.get('control_id', n): n for n, c in video_controls.items()
        }

        video_controls = [
            (n, c)
            for (n, c) in list(video_controls.items())
            if 'min' in c and 'max' in c and 'value' in c
        ]

        vid_control_params = data['vid_control_params'].split(',')
        vid_control_values = {}
        _name: str
        _value: str | int
        for param in vid_control_params:
            parts = param.split('=')
            if len(parts) == 1:
                _name, _value = param, 1

            elif len(parts) == 2:
                _name, _value = parts

            else:
                continue  # ignore any other kind of param

            _name = name_by_control_id.get(_name, _name)
            vid_control_values[_name] = _value

        ui['video_controls'] = {
            n: {
                'min': int(c['min']),
                'max': int(c['max']),
                'step': int(c['step']) if 'step' in c else None,
                'value': int(vid_control_values.get(n, c['value'])),
            }
            for n, c in video_controls
        }

        threshold = data['threshold'] * 100.0 / (data['width'] * data['height'])

    ui['frame_change_threshold'] = threshold

    if (data['@storage_device'] == 'network-share') and settings.SMB_SHARES:
        mount_point = smbctl.make_mount_point(
            data['@network_server'],
            data['@network_share_name'],
            data['@network_username'],
        )

        ui['root_directory'] = data['target_dir'][len(mount_point) :] or '/'

    elif data['@storage_device'].startswith('local-disk'):
        target_dev = data['@storage_device'][10:].replace('-', '/')
        mounted_partitions = diskctl.list_mounted_partitions()
        for partition in list(mounted_partitions.values()):
            if partition['target'] == target_dev and data['target_dir'].startswith(
                partition['mount_point']
            ):
                ui['root_directory'] = (
                    data['target_dir'][len(partition['mount_point']) :] or '/'
                )
                break

        else:  # not found for some reason
            logging.error(
                f'could not find mounted partition for device "{target_dev}" and target dir "{data["target_dir"]}"'
            )

            ui['root_directory'] = data['target_dir']

    else:
        ui['root_directory'] = data['target_dir']

    # disk usage
    usage = None
    if os.path.exists(data['target_dir']):
        usage = utils.get_disk_usage(data['target_dir'])
    if usage:
        ui['disk_used'], ui['disk_total'] = usage

    ui['text_scale'] = data['text_scale']
    text_left = data['text_left']
    text_right = data['text_right']
    if text_left or text_right:
        ui['text_overlay'] = True

        if text_left == data['camera_name']:
            ui['left_text'] = 'camera-name'

        elif text_left == '%Y-%m-%d\\n%T':
            ui['left_text'] = 'timestamp'

        elif text_left == '':
            ui['left_text'] = 'disabled'

        else:
            ui['left_text'] = 'custom-text'
            ui['custom_left_text'] = text_left

        if text_right == data['camera_name']:
            ui['right_text'] = 'camera-name'

        elif text_right == '%Y-%m-%d\\n%T':
            ui['right_text'] = 'timestamp'

        elif text_right == '':
            ui['right_text'] = 'disabled'

        else:
            ui['right_text'] = 'custom-text'
            ui['custom_right_text'] = text_right

    emulate_motion = data['emulate_motion']
    picture_output = data['picture_output']
    picture_filename = data['picture_filename']
    snapshot_interval = data['snapshot_interval']
    snapshot_filename = data['snapshot_filename']

    ui['still_images'] = bool(snapshot_filename) or bool(picture_filename)

    if emulate_motion:
        ui['capture_mode'] = 'all-frames'
        if picture_filename:
            ui['image_file_name'] = picture_filename

    elif snapshot_interval:
        ui['capture_mode'] = 'interval-snapshots'
        ui['snapshot_interval'] = snapshot_interval
        if snapshot_filename:
            ui['image_file_name'] = snapshot_filename

    elif picture_output:
        if picture_output == 'best':
            ui['capture_mode'] = 'motion-triggered-one'

        else:
            ui['capture_mode'] = 'motion-triggered'

        if picture_filename:
            ui['image_file_name'] = picture_filename

    else:  # assuming manual
        ui['capture_mode'] = 'manual'
        if snapshot_filename:
            ui['image_file_name'] = snapshot_filename

    if data['movie_output']:
        ui['movies'] = True

    if emulate_motion:
        ui['recording_mode'] = 'continuous'

    else:
        ui['recording_mode'] = 'motion-triggered'

    ui['movie_format'] = data['movie_codec']
    ui['movie_quality'] = data['movie_quality']

    # masks
    if data['mask_file']:
        ui['motion_mask'] = True
        ui['motion_mask_type'] = 'editable'

        capture_width, capture_height = data.get('width'), data.get('height')
        if int(cast(int, data.get('rotate'))) in [90, 270]:
            capture_width, capture_height = capture_height, capture_width

        ui['motion_mask_lines'] = utils.parse_editable_mask_file(
            data['@id'], 'motion', capture_width, capture_height
        )

    elif data['smart_mask_speed']:
        ui['motion_mask'] = True
        ui['motion_mask_type'] = 'smart'
        ui['smart_mask_sluggishness'] = 11 - data['smart_mask_speed']

    if data['mask_privacy']:
        ui['privacy_mask'] = True

        capture_width, capture_height = data.get('width'), data.get('height')
        if int(cast(int, data.get('rotate'))) in [90, 270]:
            capture_width, capture_height = capture_height, capture_width

        ui['privacy_mask_lines'] = utils.parse_editable_mask_file(
            data['@id'], 'privacy', capture_width, capture_height
        )

    # working schedule
    working_schedule = data['@working_schedule']
    if working_schedule:
        days = working_schedule.split('|')
        ui['working_schedule'] = True
        ui['monday_from'], ui['monday_to'] = days[0].split('-')
        ui['tuesday_from'], ui['tuesday_to'] = days[1].split('-')
        ui['wednesday_from'], ui['wednesday_to'] = days[2].split('-')
        ui['thursday_from'], ui['thursday_to'] = days[3].split('-')
        ui['friday_from'], ui['friday_to'] = days[4].split('-')
        ui['saturday_from'], ui['saturday_to'] = days[5].split('-')
        ui['sunday_from'], ui['sunday_to'] = days[6].split('-')
        ui['working_schedule_type'] = data['@working_schedule_type']

    # event start
    on_event_start = data.get('on_event_start') or []
    if on_event_start:
        on_event_start = utils.split_semicolon(on_event_start)

    ui['email_notifications_picture_time_span'] = 0
    ui['telegram_notifications_picture_time_span'] = 0
    command_notifications = []
    for e in on_event_start:
        if ' sendmail ' in e and e.endswith(_SHORT):
            ui['email_notifications_enabled'] = True
            ui.update(_settings_to_ui(data, SENDMAIL_KEYS))

        elif ' sendtelegram ' in e and e.endswith(_SHORT):
            ui['telegram_notifications_enabled'] = True
            ui.update(_settings_to_ui(data, SENDTELEGRAM_KEYS))

        elif ' webhook ' in e and _parsable(e, 'on_event_start', data['@id']):
            e = split(e)

            if len(e) < 3:
                continue

            ui['web_hook_notifications_enabled'] = True
            ui['web_hook_notifications_http_method'] = e[-2]
            ui['web_hook_notifications_url'] = e[-1]
            ui['web_hook_notifications_verify'] = '--no-verify' not in e[:-2]

        elif 'relayevent' in e:
            continue  # ignore internal relay script

        else:  # custom command
            command_notifications.append(e)

    if command_notifications:
        ui['command_notifications_enabled'] = True
        ui['command_notifications_exec'] = '; '.join(command_notifications)

    # event end
    on_event_end = data.get('on_event_end') or []
    if on_event_end:
        on_event_end = utils.split_semicolon(on_event_end)

    command_end_notifications = []
    for e in on_event_end:
        if ' webhook ' in e and _parsable(e, 'on_event_end', data['@id']):
            e = split(e)

            if len(e) < 3:
                continue

            ui['web_hook_end_notifications_enabled'] = True
            ui['web_hook_end_notifications_http_method'] = e[-2]
            ui['web_hook_end_notifications_url'] = e[-1]
            ui['web_hook_end_notifications_verify'] = '--no-verify' not in e[:-2]

        elif 'relayevent' in e or 'eventrelay.py' in e:
            continue  # ignore internal relay script

        else:  # custom command
            command_end_notifications.append(e)

    if command_end_notifications:
        ui['command_end_notifications_enabled'] = True
        ui['command_end_notifications_exec'] = '; '.join(command_end_notifications)

    # movie end
    on_movie_end = data.get('on_movie_end') or []
    if on_movie_end:
        on_movie_end = utils.split_semicolon(on_movie_end)

    command_storage = []
    for e in on_movie_end:
        if ' webhook ' in e and _parsable(e, 'on_movie_end', data['@id']):
            e = split(e)

            if len(e) < 3:
                continue

            ui['web_hook_storage_enabled'] = True
            ui['web_hook_storage_http_method'] = e[-2]
            ui['web_hook_storage_url'] = e[-1]
            ui['web_hook_storage_verify'] = '--no-verify' not in e[:-2]

        elif 'relayevent' in e:
            continue  # ignore internal relay script

        else:  # custom command
            command_storage.append(e)

    if command_storage:
        ui['command_storage_enabled'] = True
        ui['command_storage_exec'] = '; '.join(command_storage)

    # extra motion options
    extra_options = []
    for name, value in list(data.items()):
        if name not in _USED_MOTION_OPTIONS and not name.startswith('@'):
            if isinstance(value, bool):
                # boolean values should be transferred as on/off
                value = ['off', 'on'][value]

            extra_options.append((name, value))

    ui['extra_options'] = extra_options

    # action commands
    action_commands = get_action_commands(data)
    ui['actions'] = list(action_commands.keys())

    return ui


def simple_mjpeg_camera_ui_to_dict(ui: dict, prev_config: dict | None = None):
    prev_config = dict(prev_config or {})

    data = {
        # device
        'camera_name': ui['name'],
        '@enabled': ui['enabled'],
        '@admin_only': input_or_stored(ui, 'admin_only', prev_config, False),
    }

    prev_config.update(data)

    return prev_config


def simple_mjpeg_camera_dict_to_ui(data: dict) -> dict:
    ui = {
        'name': data['camera_name'],
        'enabled': data['@enabled'],
        'id': data['@id'],
        'proto': 'mjpeg',
        'url': data['@url'],
        'admin_only': data.get('@admin_only', False),
    }

    # action commands
    action_commands = get_action_commands(data)
    ui['actions'] = list(action_commands.keys())

    return ui


def get_action_commands(camera_config: dict) -> dict:
    camera_id: int = camera_config['@id']

    action_commands: dict = {}
    for action in _ACTIONS:
        path = os.path.join(settings.CONF_PATH, f'{action}_{camera_id}')
        if os.access(path, os.X_OK):
            action_commands[action] = path

    if camera_config.get('@manual_snapshots') and bool(
        camera_config.get('snapshot_filename')
    ):
        action_commands['snapshot'] = True

    if camera_config.get('@motion_event_button'):
        action_commands['motion_event'] = True

    if camera_config.get('@motion_detection_button'):
        action_commands['motion_detection'] = True

    return action_commands


def get_monitor_command(camera_id: int) -> str:
    if camera_id not in _monitor_command_cache:
        path = os.path.join(settings.CONF_PATH, f'monitor_{camera_id}')
        if os.access(path, os.X_OK):
            _monitor_command_cache[camera_id] = path

        else:
            _monitor_command_cache[camera_id] = None

    return _monitor_command_cache[camera_id]


def invalidate_monitor_commands() -> None:
    _monitor_command_cache.clear()


def backup() -> bytes | None:
    logging.debug('generating config backup file')

    files = [
        f
        for p in ('motion.conf', 'camera-*.conf', 'mask_*.pgm')
        for f in glob(os.path.join(settings.CONF_PATH, p))
    ]

    try:
        buf = BytesIO()
        with tarfile.open(fileobj=buf, mode='w:gz') as tf:
            for f in files:
                tf.add(f, arcname=os.path.basename(f))

        logging.debug(f'backup file created ({buf.tell()} bytes)')
        return buf.getvalue()

    except Exception:
        logging.exception('backup failed')
        return None


def restore(content: bytes) -> dict | None:
    logging.info('restoring config from backup file')

    patterns = ['motion.conf', 'camera-*.conf', 'mask_*.pgm']

    try:
        with tarfile.open(fileobj=BytesIO(content)) as tf:
            members = []
            for m in tf.getmembers():  # use filter='data' once we require Python 3.12+
                if not m.isfile():
                    continue

                # allow leading ./ to support full dir backups from v0.44.0b1 and earlier
                name = m.name
                while name.startswith('./'):
                    name = name[2:]

                # refuse any other directory structure, needed since fnmatchcase() * matches / as well
                if '/' in name:
                    continue

                if any(fnmatchcase(name, p) for p in patterns):
                    members.append(m)

            tf.extractall(settings.CONF_PATH, members=members)  # nosec B202

        logging.debug('configuration restored successfully')

        if settings.ENABLE_REBOOT:
            IOLoop.current().call_later(2, PowerControl.reboot)

        else:
            invalidate()

        return {'reboot': settings.ENABLE_REBOOT}

    except Exception:
        logging.exception('failed to restore configuration')
        return None


def invalidate() -> None:
    global _main_config_cache
    global _camera_config_cache
    global _camera_ids_cache

    logging.debug('invalidating config cache')
    _main_config_cache = None
    _camera_config_cache = {}
    _camera_ids_cache = None


def _value_to_python(value: str) -> bool | float | str:
    value_lower = value.lower()
    if value_lower == 'off':
        return False

    elif value_lower == 'on':
        return True

    try:
        return int(value)

    except ValueError:
        try:
            return float(value)

        except ValueError:
            return value


def _python_to_value(value: bool | float | str) -> str:
    if value is True:
        return 'on'

    elif value is False:
        return 'off'

    elif isinstance(value, (int, float)):
        return str(value)

    elif isinstance(value, str):
        return value.replace('\r', ' ').replace('\n', ' ')

    else:
        return value


def _conf_to_dict(
    lines: list,
    list_names: list | None = None,
    no_convert: list | None = None,
) -> dict:
    if list_names is None:
        list_names = []

    if no_convert is None:
        no_convert = []

    data: dict = OrderedDict()

    for line in lines:
        if len(line) == 0:  # empty line
            continue

        _match = match(r'^#\s*(@\w+)\s*(.*)', line)
        if _match:
            name, value = _match.groups()[:2]

        elif line.startswith(('#', ';')):  # comment line
            continue

        else:
            parts = line.split(None, 1)
            if len(parts) == 1:  # empty value
                parts.append('')

            name, value = parts

            value = value.strip()

        if name not in no_convert:
            value = _value_to_python(value)

        if name in list_names:
            data.setdefault(name, []).append(value)

        else:
            data[name] = value

    return data


def _dict_to_conf(lines: list, data: dict, list_names: list | None = None) -> list:
    if list_names is None:
        list_names = []

    conf_lines = []
    remaining = OrderedDict(data)
    processed = set()

    # parse existing lines and replace the values

    for line in lines:
        line = line.strip()
        if len(line) == 0:  # empty line
            conf_lines.append(line)
            continue

        _match = match(r'^#\s*(@\w+)\s*(.*)', line)
        if _match:  # @line
            name, value = _match.groups()[:2]

        elif line.startswith(('#', ';')):  # simple comment line
            conf_lines.append(line)
            continue

        else:
            parts = line.split(None, 1)
            if len(parts) == 2:
                name, value = parts

            else:
                name, value = parts[0], ''

        if name in processed:
            continue  # name already processed

        processed.add(name)

        if name in list_names:
            new_value = data.get(name)
            if new_value is not None:
                for v in new_value:
                    if v is None:
                        continue

                    line = name + ' ' + _python_to_value(v)
                    conf_lines.append(line)

            else:
                line = name + ' ' + value
                conf_lines.append(line)

        else:
            new_value = data.get(name)
            if new_value is not None:
                value = _python_to_value(new_value)
                line = name + ' ' + value
                conf_lines.append(line)

        remaining.pop(name, None)

    # add the remaining config values not covered by existing lines
    if len(remaining) and len(lines):
        conf_lines.append('')  # add a blank line

    for name, value in list(remaining.items()):
        if name in list_names:
            for v in value:
                if v is None:
                    continue

                line = name + ' ' + _python_to_value(v)
                conf_lines.append(line)

        else:
            line = name + ' ' + _python_to_value(value)
            conf_lines.append(line)

    # build the final config lines
    conf_lines.sort(key=lambda line: not line.startswith('@'))

    lines = []
    for i, line in enumerate(conf_lines):
        # squeeze successive blank lines
        if i > 0 and len(line.strip()) == 0 and len(conf_lines[i - 1].strip()) == 0:
            continue

        if line.startswith('@'):
            line = '# ' + line

        elif i > 0 and conf_lines[i - 1].startswith('@'):
            lines.append('')  # add a blank line between @lines and the rest

        lines.append(line)

    return lines


def _set_default_motion(data: dict) -> None:
    data.setdefault('@enabled', True)

    data.setdefault('@admin_username', 'admin')
    data.setdefault('@admin_password', '')
    data.setdefault('@normal_username', 'user')
    data.setdefault('@normal_password', '')
    data.setdefault('@lang', 'en')

    data.setdefault('setup_mode', False)
    data.setdefault('webcontrol_port', settings.MOTION_CONTROL_PORT)
    data.setdefault('webcontrol_interface', 1)
    data.setdefault('webcontrol_localhost', settings.MOTION_CONTROL_LOCALHOST)
    data.setdefault('webcontrol_parms', 0)


def _set_motion_control_auth(data: dict) -> bool:
    # motionEye sends the credentials from motioneye.conf with each request to
    # the control interface, hence they always override those in motion.conf
    old = (data.get('webcontrol_authentication'), data.get('webcontrol_auth_method'))

    if settings.MOTION_CONTROL_AUTHENTICATION:
        data['webcontrol_authentication'] = settings.MOTION_CONTROL_AUTHENTICATION
        data['webcontrol_auth_method'] = 1  # basic

    else:
        data.pop('webcontrol_authentication', None)
        data.pop('webcontrol_auth_method', None)

    return old != (
        data.get('webcontrol_authentication'),
        data.get('webcontrol_auth_method'),
    )


def _set_default_motion_camera(camera_id: int, data: dict) -> None:
    data.setdefault('camera_name', 'Camera' + str(camera_id))
    data.setdefault('@id', camera_id)
    data.setdefault('@admin_only', False)

    if utils.is_v4l2_camera(data):
        data.setdefault('videodevice', '/dev/video0')
        data.setdefault('vid_control_params', '')
        data.setdefault('width', 352)
        data.setdefault('height', 288)

    data.setdefault('auto_brightness', False)
    data.setdefault('framerate', 2)
    data.setdefault('rotate', 0)
    data.setdefault('mask_privacy', '')

    data.setdefault('@storage_device', 'custom-path')
    data.setdefault('@network_server', '')
    data.setdefault('@network_share_name', '')
    data.setdefault('@network_smb_ver', '1.0')
    data.setdefault('@network_username', '')
    data.setdefault('@network_password', '')
    data.setdefault(
        'target_dir', os.path.join(settings.MEDIA_PATH, data['camera_name'])
    )
    data.setdefault('@upload_enabled', False)
    data.setdefault('@upload_picture', True)
    data.setdefault('@upload_movie', True)
    data.setdefault('@upload_service', 'ftp')
    data.setdefault('@upload_server', '')
    data.setdefault('@upload_port', '')
    data.setdefault('@upload_method', 'POST')
    data.setdefault('@upload_location', '')
    data.setdefault('@upload_subfolders', True)
    data.setdefault('@upload_username', '')
    data.setdefault('@upload_password', '')
    data.setdefault('@upload_tls', False)
    data.setdefault('@upload_verify', True)
    data.setdefault('@upload_endpoint_url', '')
    data.setdefault('@upload_access_key', '')
    data.setdefault('@upload_secret_key', '')
    data.setdefault('@upload_bucket', '')
    data.setdefault('@upload_sse_c_key', '')
    data.setdefault('@clean_cloud_enabled', False)
    data.setdefault('@clean_uploaded', False)

    data.setdefault('stream_localhost', True)
    data.setdefault('stream_port', 9080 + camera_id)
    data.setdefault('stream_maxrate', 5)
    data.setdefault('stream_quality', 85)
    data.setdefault('stream_motion', False)
    data.setdefault('stream_auth_method', 0)

    data.setdefault('@webcam_resolution', 100)
    data.setdefault('@webcam_server_resize', False)

    data.setdefault('text_left', data['camera_name'])
    data.setdefault('text_right', '%Y-%m-%d\\n%T')
    data.setdefault('text_scale', 1)

    data.setdefault('@motion_detection', True)
    data.setdefault('@motion_event_button', False)
    data.setdefault('@motion_detection_button', False)
    data.setdefault('text_changes', False)
    data.setdefault('locate_motion_mode', False)
    data.setdefault('locate_motion_style', 'redbox')

    data.setdefault('threshold', 2000)
    data.setdefault('threshold_maximum', 0)
    data.setdefault('threshold_tune', False)
    data.setdefault('noise_tune', True)
    data.setdefault('noise_level', 32)
    data.setdefault('lightswitch_percent', 0)
    data.setdefault('despeckle_filter', '')
    data.setdefault('minimum_motion_frames', 20)
    data.setdefault('smart_mask_speed', 0)
    data.setdefault('mask_file', '')
    data.setdefault('movie_output_motion', False)
    data.setdefault('picture_output_motion', False)

    data.setdefault('pre_capture', 1)
    data.setdefault('post_capture', 1)

    data.setdefault('picture_output', False)
    data.setdefault('picture_filename', '')
    data.setdefault('emulate_motion', False)
    data.setdefault('event_gap', 30)

    data.setdefault('snapshot_interval', 0)
    data.setdefault('snapshot_filename', '')
    data.setdefault('picture_quality', 85)
    data.setdefault('@preserve_pictures', 0)
    data.setdefault('@manual_snapshots', True)

    data.setdefault('movie_filename', '%Y-%m-%d/%H-%M-%S')
    data.setdefault('movie_max_time', 0)
    data.setdefault('movie_output', False)
    data.setdefault('movie_passthrough', False)

    if motionctl.has_h264_omx_support():
        data.setdefault('movie_codec', 'mp4:h264_omx')  # will use h264 codec

    elif motionctl.has_h264_v4l2m2m_support():
        data.setdefault('movie_codec', 'mp4:h264_v4l2m2m')  # will use h264 codec

    else:
        data.setdefault('movie_codec', 'mp4')  # will use h264 codec

    data.setdefault('movie_quality', 75)  # 75%

    data.setdefault('@preserve_movies', 0)

    data.setdefault('@working_schedule', '')
    data.setdefault('@working_schedule_type', 'outside')

    data.setdefault('on_event_start', '')
    data.setdefault('on_event_end', '')
    data.setdefault('on_movie_end', '')
    data.setdefault('on_picture_save', '')


def _set_default_simple_mjpeg_camera(camera_id: int, data: dict) -> None:
    data.setdefault('camera_name', 'Camera' + str(camera_id))
    data.setdefault('@id', camera_id)
    data.setdefault('@admin_only', False)


def set_admin_password(password: str) -> None:
    main_config = get_main()
    main_config['@admin_password'] = ph.hash(password)
    set_main(main_config)


def set_normal_password(password: str) -> None:
    main_config = get_main()
    main_config['@normal_password'] = ph.hash(password)
    set_main(main_config)
