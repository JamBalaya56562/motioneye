# Copyright (c) 2013 Calin Crisan
# This file is part of motionEye.
#
# motionEye is free software: you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation, either version 3 of the License, or
# (at your option) any later version.
#
# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with this program.  If not, see <http://www.gnu.org/licenses/>.
from __future__ import annotations

import json
import logging
import re
from math import isfinite
from time import time
from urllib.parse import urlencode

from tornado.httpclient import AsyncHTTPClient, HTTPRequest, HTTPResponse

from motioneye import settings, utils
from motioneye.utils.authstate import generate_hmac_signature, generate_nonce

_DOUBLE_SLASH_REGEX = re.compile('//+')


def _make_request(
    scheme,
    host,
    port,
    remote_secret,
    path,
    method='GET',
    data=None,
    query=None,
    timeout=None,
    content_type=None,
    validate_cert=True,
):
    path = _DOUBLE_SLASH_REGEX.sub('/', path)
    query = dict(query or {})
    qs = urlencode(query)
    uri = (path + ('&' if '?' in path else '?') + qs) if qs else path

    url = '{scheme}://{host}{port}{uri}'.format(
        scheme=scheme, host=host, port=':' + str(port) if port else '', uri=uri or ''
    )

    # Use HMAC authentication instead of query parameters
    headers = {}
    if content_type:
        headers['Content-Type'] = content_type

    if remote_secret:
        timestamp = str(int(time()))
        nonce = generate_nonce()
        signature = generate_hmac_signature(
            remote_secret, method, uri, timestamp, nonce, data
        )

        headers['X-HMAC-Signature'] = signature
        headers['X-Timestamp'] = timestamp
        headers['X-Nonce'] = nonce
    if timeout is None:
        timeout = settings.REMOTE_REQUEST_TIMEOUT

    return HTTPRequest(
        url,
        method,
        body=data,
        connect_timeout=timeout,
        request_timeout=timeout,
        headers=headers,
        validate_cert=validate_cert,
        follow_redirects=False,
    )


async def _send_request(request: HTTPRequest) -> HTTPResponse:
    try:
        # The raise_error=False argument only affects the HTTPError raised when a non-200 response
        # code is used, instead of suppressing all errors.
        response = await AsyncHTTPClient().fetch(request, raise_error=False)

        if response.code != 200:
            decoded = json.loads(response.body)
            if decoded['error'] == 'unauthorized':
                response.error = Exception('Authentication Error')

            elif decoded['error']:
                response.error = Exception(decoded['error'])

        elif response.headers.get('Content-Type', '').startswith('application/json'):
            decoded = json.loads(response.body)
            if isinstance(decoded, dict) and decoded.get('error'):
                response.error = utils.RemoteError(decoded['error'])
    except Exception as e:
        logging.error(f"_send_request: {e}")
        response = HTTPResponse(request, 599)
        response.error = e

    return response


def pretty_camera_url(local_config, camera=True):
    scheme = local_config.get('@scheme', local_config.get('scheme')) or 'http'
    host = local_config.get('@host', local_config.get('host'))
    port = local_config.get('@port', local_config.get('port'))
    path = local_config.get('@path', local_config.get('path')) or ''

    url = scheme + '://' + host
    if port and str(port) not in ['80', '443']:
        url += ':' + str(port)

    if path:
        url += path

    url = url.removesuffix('/')

    if camera:
        if camera is True:
            url += '/config/' + str(
                local_config.get(
                    '@remote_camera_id', local_config.get('remote_camera_id')
                )
            )

        else:
            url += '/config/' + str(camera)

    return url


def _verify_flag(local_config) -> bool:
    value = local_config.get('@remote_verify', local_config.get('remote_verify'))

    return utils.verify_setting(value)


def _remote_params(local_config):
    params = [
        local_config.get('@scheme', local_config.get('scheme')) or 'http',
        local_config.get('@host', local_config.get('host')),
        local_config.get('@port', local_config.get('port')),
        local_config.get('@remote_secret', local_config.get('remote_secret')),
        local_config.get('@path', local_config.get('path')) or '',
        local_config.get('@remote_camera_id', local_config.get('remote_camera_id')),
        _verify_flag(local_config),
    ]

    if params[3] is not None:
        params[3] = str(params[3])

    if params[4] is not None:
        params[4] = str(params[4])

    if params[5] is not None:
        params[5] = str(params[5])

    return params


def make_camera_response(c):
    return {'id': c.get('id'), 'name': c.get('name')}


async def list_cameras(local_config) -> utils.GetCamerasResponse:
    scheme, host, port, remote_secret, path, _camera_id, verify = _remote_params(
        local_config
    )

    logging.debug(
        f'listing remote cameras on {pretty_camera_url(local_config, camera=False)}'
    )

    request = _make_request(
        scheme, host, port, remote_secret, path + '/config/list/', validate_cert=verify
    )

    response = await _send_request(request)

    if response.error:
        logging.error(
            'failed to list remote cameras on '
            f'{pretty_camera_url(local_config, camera=False)}: {utils.pretty_http_error(response)}'
        )

        return utils.GetCamerasResponse(None, utils.pretty_http_error(response))

    try:
        response = json.loads(response.body)

    except Exception as e:
        logging.error(
            f'failed to decode json answer from {pretty_camera_url(local_config, camera=False)}: {e}'
        )

        return utils.GetCamerasResponse(None, str(e))

    else:
        cameras = response.get('cameras') if isinstance(response, dict) else None
        if not isinstance(cameras, list) or not all(
            isinstance(c, dict) for c in cameras
        ):
            logging.error(
                f'unexpected answer from {pretty_camera_url(local_config, camera=False)}'
            )

            return utils.GetCamerasResponse(None, 'unexpected answer')

        # filter out simple mjpeg cameras
        cameras = [
            make_camera_response(c)
            for c in cameras
            if c.get('proto') != 'mjpeg' and c.get('enabled')
        ]

        return utils.GetCamerasResponse(cameras, None)


async def get_config(local_config) -> utils.GetConfigResponse:
    scheme, host, port, remote_secret, path, camera_id, verify = _remote_params(
        local_config
    )

    logging.debug(
        f'getting config for remote camera {camera_id} on {pretty_camera_url(local_config)}'
    )

    request = _make_request(
        scheme,
        host,
        port,
        remote_secret,
        path + f'/config/{camera_id}/get/',
        validate_cert=verify,
    )
    response = await _send_request(request)

    if response.error:
        logging.error(
            'failed to get config for remote camera '
            f'{camera_id} on {pretty_camera_url(local_config)}: {utils.pretty_http_error(response)}'
        )

        return utils.GetConfigResponse(None, error=utils.pretty_http_error(response))

    try:
        response = json.loads(response.body)

    except Exception as e:
        logging.error(
            f'failed to decode json answer from {pretty_camera_url(local_config)}: {e}'
        )

        return utils.GetConfigResponse(None, error=str(e))

    else:
        if not isinstance(response, dict):
            logging.error(f'unexpected answer from {pretty_camera_url(local_config)}')

            return utils.GetConfigResponse(None, error='unexpected answer')

        response['host'] = host
        response['port'] = port

        # Only forward an empty string, which indicates that no password is set.
        # New backends send nothing if a password is set, but old backends send
        # "*****" instead, which is unset here to align with new behavior.
        if (
            response.get('streaming_password') is not None
            and response['streaming_password'] != ''
        ):
            del response['streaming_password']

        return utils.GetConfigResponse(remote_ui_config=response, error=None)


async def set_config(local_config, ui_config) -> str | None:
    scheme, host, port, remote_secret, path, camera_id, verify = _remote_params(
        local_config
    )

    logging.debug(
        f'setting config for remote camera {camera_id} on {pretty_camera_url(local_config)}'
    )

    ui_config = json.dumps(ui_config)

    p = path + f'/config/{camera_id}/set/'
    request = _make_request(
        scheme,
        host,
        port,
        remote_secret,
        p,
        method='POST',
        data=ui_config.encode(),
        content_type='application/json',
        validate_cert=verify,
    )
    response = await _send_request(request)

    result = None

    if response.error:
        logging.error(
            'failed to set config for remote camera '
            f'{camera_id} on {pretty_camera_url(local_config)}: {utils.pretty_http_error(response)}'
        )

        result = utils.pretty_http_error(response)

    return result


async def test(local_config, data) -> utils.CommonExternalResponse:
    scheme, host, port, remote_secret, path, camera_id, verify = _remote_params(
        local_config
    )
    what = data['what']
    logging.debug(
        f'testing {what} on remote camera {camera_id}, on {pretty_camera_url(local_config)}'
    )

    data = json.dumps(data)

    p = path + f'/config/{camera_id}/test/'
    request = _make_request(
        scheme,
        host,
        port,
        remote_secret,
        p,
        method='POST',
        data=data,
        content_type='application/json',
        validate_cert=verify,
    )
    response = await _send_request(request)
    if response.error:
        logging.error(
            f'failed to test {what} on remote camera {camera_id}, '
            f'on {pretty_camera_url(local_config)}: {utils.pretty_http_error(response)}'
        )

        return utils.CommonExternalResponse(
            None, error=utils.pretty_http_error(response)
        )

    return utils.CommonExternalResponse(
        None, None
    )  # it will never return result = True, what the point?


async def get_authorize_url(local_config, service: str) -> str | None:
    scheme, host, port, remote_secret, path, camera_id, verify = _remote_params(
        local_config
    )
    request = _make_request(
        scheme,
        host,
        port,
        remote_secret,
        path + f'/config/{camera_id}/authorize/',
        query={'service': service},
        validate_cert=verify,
    )
    try:
        response = await AsyncHTTPClient().fetch(request, raise_error=False)

    except Exception as e:
        logging.error(f'failed to get the authorization url of {service}: {e}')
        return None

    # the remote answers with a redirect to the authorization url
    url = response.headers.get('Location') if response.code in (301, 302) else None
    if not url:
        logging.error(
            f'failed to get the authorization url of {service} from remote camera '
            f'{camera_id}, on {pretty_camera_url(local_config)}: {response.code}'
        )

    return url


async def get_current_picture(
    local_config, width, height
) -> utils.GetCurrentPictureResponse:
    scheme, host, port, remote_secret, path, camera_id, verify = _remote_params(
        local_config
    )

    logging.debug(
        f'getting current picture for remote camera {camera_id} on {pretty_camera_url(local_config)}'
    )

    query = {}

    if width:
        query['width'] = str(width)

    if height:
        query['height'] = str(height)

    p = path + f'/picture/{camera_id}/current/'

    request = _make_request(
        scheme, host, port, remote_secret, p, query=query, validate_cert=verify
    )
    response = await _send_request(request)

    if response.error:
        logging.error(
            'failed to get current picture for remote camera '
            f'{camera_id} on {pretty_camera_url(local_config)}: {utils.pretty_http_error(response)}'
        )
        return utils.GetCurrentPictureResponse(error=utils.pretty_http_error(response))

    cookies = utils.parse_cookies(response.headers.get_list('Set-Cookie'))
    motion_detected = cookies.get('motion_detected_' + str(camera_id)) == 'true'
    motion_detection: bool | None = None
    motion_detection_cookie: str | None = cookies.get(
        'motion_detection_' + str(camera_id)
    )
    if motion_detection_cookie is not None:
        motion_detection = motion_detection_cookie == 'true'
    try:
        capture_fps = float(cookies.get('capture_fps_' + str(camera_id)) or 0.0)

    except ValueError:
        capture_fps = 0.0

    if not isfinite(capture_fps) or capture_fps < 0:
        capture_fps = 0.0

    monitor_info = cookies.get('monitor_info_' + str(camera_id))

    return utils.GetCurrentPictureResponse(
        motion_detected=motion_detected,
        motion_detection=motion_detection,
        capture_fps=capture_fps,
        monitor_info=monitor_info,
        picture=response.body,
    )


async def list_media(
    local_config, media_type, prefix: str | None = None
) -> utils.ListMediaResponse:
    utils.validate_paths(prefix)

    scheme, host, port, remote_secret, path, camera_id, verify = _remote_params(
        local_config
    )

    logging.debug(
        f'getting media list for remote camera {camera_id} on {pretty_camera_url(local_config)}'
    )

    query = {}
    if prefix is not None:
        query['prefix'] = prefix

    # timeout here is 10 times larger than usual - we expect a big delay when fetching the media list
    p = path + f'/{media_type}/{camera_id}/list/'
    request = _make_request(
        scheme,
        host,
        port,
        remote_secret,
        p,
        query=query,
        timeout=10 * settings.REMOTE_REQUEST_TIMEOUT,
        validate_cert=verify,
    )
    response = await _send_request(request)
    if response.error:
        logging.error(
            'failed to get media list for remote camera '
            f'{camera_id} on {pretty_camera_url(local_config)}: {utils.pretty_http_error(response)}'
        )

        return utils.ListMediaResponse(error=utils.pretty_http_error(response))

    try:
        response = json.loads(response.body)

    except Exception as e:
        logging.error(
            f'failed to decode json answer from {pretty_camera_url(local_config)}: {e}'
        )

        return utils.ListMediaResponse(error=str(e))

    return utils.ListMediaResponse(media_list=response)


async def get_media_content(
    local_config: dict, filename: str, media_type: str
) -> utils.CommonExternalResponse:
    utils.validate_paths(filename)

    scheme, host, port, remote_secret, path, camera_id, verify = _remote_params(
        local_config
    )

    logging.debug(
        f'downloading file {filename} of remote camera {camera_id} on {pretty_camera_url(local_config)}'
    )

    path += f'/{media_type}/{camera_id}/download/{filename}'

    # timeout here is 10 times larger than usual - we expect a big delay when fetching the media list
    request = _make_request(
        scheme,
        host,
        port,
        remote_secret,
        path,
        timeout=10 * settings.REMOTE_REQUEST_TIMEOUT,
        validate_cert=verify,
    )
    response = await _send_request(request)
    if response.error:
        logging.error(
            f'failed to download file {filename} of remote camera {camera_id} '
            f'on {pretty_camera_url(local_config)}: {utils.pretty_http_error(response)}'
        )

        return utils.CommonExternalResponse(error=utils.pretty_http_error(response))

    return utils.CommonExternalResponse(result=response.body)


async def make_zipped_content(
    local_config, media_type, group: str
) -> utils.CommonExternalResponse:
    utils.validate_paths(group)

    scheme, host, port, remote_secret, path, camera_id, verify = _remote_params(
        local_config
    )

    logging.debug(
        'preparing zip file for group "{group}" of remote camera {id} on {url}'.format(
            group=group or 'ungrouped',
            id=camera_id,
            url=pretty_camera_url(local_config),
        )
    )

    prepare_path = path + f'/{media_type}/{camera_id}/zipped/{group}/'

    # timeout here is 100 times larger than usual - we expect a big delay
    request = _make_request(
        scheme,
        host,
        port,
        remote_secret,
        prepare_path,
        timeout=100 * settings.REMOTE_REQUEST_TIMEOUT,
        validate_cert=verify,
    )
    response = await _send_request(request)
    if response.error:
        msg = (
            'failed to prepare zip file for group "{group}" '
            'of remote camera {id} on {url}: {msg}'.format(
                group=group or 'ungrouped',
                id=camera_id,
                url=pretty_camera_url(local_config),
                msg=utils.pretty_http_error(response),
            )
        )

        logging.error(msg)

        return utils.CommonExternalResponse(error=utils.pretty_http_error(response))

    try:
        key = json.loads(response.body)['key']

    except Exception as e:
        logging.error(
            f'failed to decode json answer from {pretty_camera_url(local_config)}: {e}'
        )

        return utils.CommonExternalResponse(error=str(e))
    else:
        return utils.CommonExternalResponse(result={'key': key})


async def get_zipped_content(
    local_config, media_type, key, group: str
) -> utils.CommonExternalResponse:
    utils.validate_paths(group)

    scheme, host, port, remote_secret, path, camera_id, verify = _remote_params(
        local_config
    )

    logging.debug(
        f'downloading zip file for remote camera {camera_id} on {pretty_camera_url(local_config)}'
    )

    p = path + f'/{media_type}/{camera_id}/zipped/{group}/?key={key}'

    request = _make_request(
        scheme,
        host,
        port,
        remote_secret,
        p,
        timeout=10 * settings.REMOTE_REQUEST_TIMEOUT,
        validate_cert=verify,
    )
    response = await _send_request(request)
    if response.error:
        logging.error(
            'failed to download zip file for remote camera '
            f'{camera_id} on {pretty_camera_url(local_config)}: {utils.pretty_http_error(response)}'
        )

        return utils.CommonExternalResponse(error=utils.pretty_http_error(response))

    return utils.CommonExternalResponse(
        result={
            'data': response.body,
            'content_type': response.headers.get('Content-Type'),
            'content_disposition': response.headers.get('Content-Disposition'),
        }
    )


async def make_timelapse_movie(
    local_config, framerate, interval, group: str
) -> utils.CommonExternalResponse:
    utils.validate_paths(group)

    scheme, host, port, remote_secret, path, camera_id, verify = _remote_params(
        local_config
    )

    msg = (
        'making timelapse movie for group "{group}" of remote camera {id} '
        'with rate {framerate}/{int} on {url}'.format(
            group=group or 'ungrouped',
            id=camera_id,
            framerate=framerate,
            int=interval,
            url=pretty_camera_url(local_config),
        )
    )

    logging.debug(msg)

    path += f'/picture/{camera_id}/timelapse/{group}/?interval={interval}&framerate={framerate}'

    request = _make_request(
        scheme,
        host,
        port,
        remote_secret,
        path,
        timeout=100 * settings.REMOTE_REQUEST_TIMEOUT,
        validate_cert=verify,
    )
    response = await _send_request(request)
    if response.error:
        msg = (
            'failed to make timelapse movie for group "{group}" of remote camera {id} '
            'with rate {framerate}/{int} on {url}: {msg}'.format(
                group=group or 'ungrouped',
                id=camera_id,
                url=pretty_camera_url(local_config),
                int=interval,
                framerate=framerate,
                msg=utils.pretty_http_error(response),
            )
        )

        logging.error(msg)

        return utils.CommonExternalResponse(error=utils.pretty_http_error(response))

    try:
        response = json.loads(response.body)

    except Exception as e:
        logging.error(
            f'failed to decode json answer from {pretty_camera_url(local_config)}: {e}'
        )

        return utils.CommonExternalResponse(error=str(e))

    else:
        if not isinstance(response, dict):
            return utils.CommonExternalResponse(error='unexpected answer')

        return utils.CommonExternalResponse(result=response)


async def check_timelapse_movie(
    local_config, group: str
) -> utils.CommonExternalResponse:
    utils.validate_paths(group)

    scheme, host, port, remote_secret, path, camera_id, verify = _remote_params(
        local_config
    )

    logging.debug(
        f'checking timelapse movie status for remote camera {camera_id} on {pretty_camera_url(local_config)}'
    )

    p = path + f'/picture/{camera_id}/timelapse/{group}/?check=true'
    request = _make_request(scheme, host, port, remote_secret, p, validate_cert=verify)
    response = await _send_request(request)

    if response.error:
        logging.error(
            'failed to check timelapse movie status for remote camera '
            f'{camera_id} on {pretty_camera_url(local_config)}: {utils.pretty_http_error(response)}'
        )

        return utils.CommonExternalResponse(error=utils.pretty_http_error(response))

    try:
        response = json.loads(response.body)

    except Exception as e:
        logging.error(
            f'failed to decode json answer from {pretty_camera_url(local_config)}: {e}'
        )

        return utils.CommonExternalResponse(error=str(e))

    else:
        if not isinstance(response, dict):
            return utils.CommonExternalResponse(error='unexpected answer')

        return utils.CommonExternalResponse(result=response)


async def get_timelapse_movie(
    local_config, key, group: str
) -> utils.CommonExternalResponse:
    utils.validate_paths(group)

    scheme, host, port, remote_secret, path, camera_id, verify = _remote_params(
        local_config
    )

    logging.debug(
        f'downloading timelapse movie for remote camera {camera_id} on {pretty_camera_url(local_config)}'
    )

    p = path + f'/picture/{camera_id}/timelapse/{group}/?key={key}'

    request = _make_request(
        scheme,
        host,
        port,
        remote_secret,
        p,
        timeout=10 * settings.REMOTE_REQUEST_TIMEOUT,
        validate_cert=verify,
    )
    response = await _send_request(request)
    if response.error:
        logging.error(
            'failed to download timelapse movie for remote camera '
            f'{camera_id} on {pretty_camera_url(local_config)}: {utils.pretty_http_error(response)}'
        )

        return utils.CommonExternalResponse(error=utils.pretty_http_error(response))

    return utils.CommonExternalResponse(
        result={
            'data': response.body,
            'content_type': response.headers.get('Content-Type'),
            'content_disposition': response.headers.get('Content-Disposition'),
        }
    )


async def get_media_preview(
    local_config: dict,
    filename: str,
    media_type: str,
    width: str | None = None,
    height: str | None = None,
) -> utils.CommonExternalResponse:
    utils.validate_paths(filename)

    scheme, host, port, remote_secret, path, camera_id, verify = _remote_params(
        local_config
    )

    logging.debug(
        f'getting file preview for {filename} of remote camera {camera_id} on {pretty_camera_url(local_config)}'
    )

    path += f'/{media_type}/{camera_id}/preview/{filename}'

    query = {}

    if width:
        query['width'] = str(width)

    if height:
        query['height'] = str(height)

    request = _make_request(
        scheme, host, port, remote_secret, path, query=query, validate_cert=verify
    )
    response = await _send_request(request)
    if response.error:
        logging.error(
            f'failed to get file preview for {filename} of remote camera {camera_id} '
            f'on {pretty_camera_url(local_config)}: {utils.pretty_http_error(response)}'
        )

        return utils.CommonExternalResponse(error=utils.pretty_http_error(response))

    return utils.CommonExternalResponse(result=response.body)


async def del_media_content(
    local_config: dict, filename: str, media_type: str
) -> utils.CommonExternalResponse:
    utils.validate_paths(filename)

    scheme, host, port, remote_secret, path, camera_id, verify = _remote_params(
        local_config
    )

    logging.debug(
        f'deleting file {filename} of remote camera {camera_id} on {pretty_camera_url(local_config)}'
    )

    path += f'/{media_type}/{camera_id}/delete/{filename}'

    request = _make_request(
        scheme,
        host,
        port,
        remote_secret,
        path,
        method='POST',
        data='{}',
        timeout=settings.REMOTE_REQUEST_TIMEOUT,
        content_type='application/json',
        validate_cert=verify,
    )
    response = await _send_request(request)
    if response.error:
        logging.error(
            f'failed to delete file {filename} of remote camera {camera_id} '
            f'on {pretty_camera_url(local_config)}: {utils.pretty_http_error(response)}'
        )

        return utils.CommonExternalResponse(error=utils.pretty_http_error(response))

    return utils.CommonExternalResponse()


async def del_media_group(
    local_config, group: str, media_type
) -> utils.CommonExternalResponse:
    if '..' in group.split('/'):
        raise ValueError(f'Path traversal detected in group "{group}"')

    scheme, host, port, remote_secret, path, camera_id, verify = _remote_params(
        local_config
    )

    logging.debug(
        'deleting group "{group}" of remote camera {id} on {url}'.format(
            group=group or 'ungrouped',
            id=camera_id,
            url=pretty_camera_url(local_config),
        )
    )

    path += f'/{media_type}/{camera_id}/delete_all/{group}/'

    request = _make_request(
        scheme,
        host,
        port,
        remote_secret,
        path,
        method='POST',
        data='{}',
        timeout=settings.REMOTE_REQUEST_TIMEOUT,
        content_type='application/json',
        validate_cert=verify,
    )
    response = await _send_request(request)
    if response.error:
        logging.error(
            'failed to delete group "{group}" of remote camera {id} on {url}: {msg}'.format(
                group=group or 'ungrouped',
                id=camera_id,
                url=pretty_camera_url(local_config),
                msg=utils.pretty_http_error(response),
            )
        )

        return utils.CommonExternalResponse(error=utils.pretty_http_error(response))

    return utils.CommonExternalResponse()


async def exec_action(local_config, action) -> utils.CommonExternalResponse:
    scheme, host, port, remote_secret, path, camera_id, verify = _remote_params(
        local_config
    )

    logging.debug(
        f'executing action "{action}" of remote camera {camera_id} on {pretty_camera_url(local_config)}'
    )

    path += f'/action/{camera_id}/{action}'

    request = _make_request(
        scheme,
        host,
        port,
        remote_secret,
        path,
        method='POST',
        data='{}',
        timeout=settings.REMOTE_REQUEST_TIMEOUT,
        content_type='application/json',
        validate_cert=verify,
    )
    response = await _send_request(request)
    if response.error:
        logging.error(
            f'failed to execute action "{action}" of remote camera {camera_id} '
            f'on {pretty_camera_url(local_config)}: {utils.pretty_http_error(response)}'
        )

        return utils.CommonExternalResponse(error=utils.pretty_http_error(response))

    return utils.CommonExternalResponse()
