# Copyright (c) 2013 Calin Crisan
# This file is part of motionEye.
#
# motionEye is free software: you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation, either version 3 of the License, or
# (at your option) any later version.
#
# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with this program.  If not, see <http://www.gnu.org/licenses/>.
from __future__ import annotations

import logging
import re
from os.path import exists, join
from subprocess import DEVNULL, CalledProcessError, Popen, TimeoutExpired
from time import sleep

from tornado.httpclient import AsyncHTTPClient, HTTPClientError, HTTPRequest
from tornado.ioloop import IOLoop

from motioneye import mediafiles, settings, update, utils
from motioneye.controls.powerctl import PowerControl

_MOTION_CONTROL_TIMEOUT: int = 5

_started: bool = False
# the motion process is a child of motionEye, so no pid file is needed to find it
_process: Popen | None = None
_motion_binary_cache: tuple[str, str] | None = None
_motion_detected: dict[int, bool] = {}
_motion_detection: dict[int, utils.GetMotionDetectionResult] = {}


def find_motion():
    global _motion_binary_cache
    if _motion_binary_cache is not None:
        return _motion_binary_cache

    # binary
    if settings.MOTION_BINARY:
        if exists(settings.MOTION_BINARY):
            binary = settings.MOTION_BINARY

        else:
            return None, None

    else:  # autodetect motion binary path
        try:
            binary = utils.call_subprocess(['which', 'motion'])

        except CalledProcessError:  # not found
            return None, None

    # version
    try:
        output = utils.call_subprocess([binary, '-h'], check=False)

    except CalledProcessError as e:  # not found as
        logging.error(f'motion version could not be found: {e}')
        return None, None

    result = re.findall('motion Version ([^,]+)', output, re.IGNORECASE)
    version = result and result[0] or ''

    logging.debug(f'found motion executable "{binary}" version "{version}"')

    _motion_binary_cache = (binary, version)

    return _motion_binary_cache


def start(deferred=False):
    from motioneye import config, mjpgclient, wsswitch

    if deferred:
        IOLoop.current().add_callback(start, deferred=False)

    global _started, _process, _motion_detection
    _started = True

    enabled_local_motion_cameras = config.get_enabled_local_motion_cameras()
    if running() or not enabled_local_motion_cameras:
        return

    logging.debug('searching motion executable')

    binary, version = find_motion()
    if not binary:
        raise FileNotFoundError('motion executable could not be found')

    logging.debug(f'starting motion executable "{binary}" version "{version}"')

    motion_cfg_path = join(settings.CONF_PATH, 'motion.conf')

    args = [binary, '-n', '-c', motion_cfg_path, '-d']

    if settings.LOG_LEVEL <= logging.DEBUG:
        args.append('9')

    elif settings.LOG_LEVEL <= logging.WARNING:
        args.append('5')

    elif settings.LOG_LEVEL <= logging.ERROR:
        args.append('4')

    else:  # fatal, quiet
        args.append('1')

    # By default, motion logs to STDERR and syslog.
    # So we mute its STDOUT/STDERR, to let it log to file or syslog only.
    # Without syslog, e.g. in a container, it inherits motionEye's instead.
    if settings.LOG_TO_FILE:
        args += ['-l', join(settings.LOG_PATH, 'motion.log')]

    if exists('/dev/log'):
        output = DEVNULL
    else:
        output = None

    process = Popen(
        args, stdout=output, stderr=output, close_fds=True, cwd=settings.CONF_PATH
    )

    # wait 2 seconds to see that the process has successfully started
    for _i in range(20):
        sleep(0.1)
        exit_code = process.poll()
        if exit_code is not None and exit_code != 0:
            raise RuntimeError(f'motion failed to start with exit code "{exit_code}"')

    _process = process

    # Clear motion detection status cache to cover start() without stop() from server._motion_checker
    _motion_detection = {}
    # motion starts with the configured state, which wsswitch has to check again
    wsswitch.clear_cache()

    # disable motion detection if version < 4.4, otherwise the new "pause" setting does
    if not is_motion_post43():
        IOLoop.current().spawn_callback(_disable_initial_motion_detection)

    # if mjpg client idle timeout is disabled, create mjpg clients for all cameras by default
    if not settings.MJPG_CLIENT_IDLE_TIMEOUT:
        logging.debug('creating default mjpg clients for local cameras')
        for camera in enabled_local_motion_cameras:
            mjpgclient.get_jpg(camera['@id'])


def stop(invalidate=False):
    from motioneye import mjpgclient

    global _started, _motion_detection
    _started = False

    # Clear motion detection status cache
    _motion_detection = {}

    if not running():
        return

    logging.debug('stopping motion')

    mjpgclient.close_all(invalidate=invalidate)

    # send the TERM signal once
    _process.terminate()

    # wait 5 seconds for the process to exit
    try:
        _process.wait(5)
        return

    except TimeoutExpired:
        pass

    # send the KILL signal once
    _process.kill()

    # wait 2 seconds for the process to exit
    try:
        _process.wait(2)
        return

    except TimeoutExpired:
        pass

    # the process still did not exit
    if settings.ENABLE_REBOOT:
        logging.error('could not terminate the motion process')
        PowerControl.reboot()

    else:
        raise RuntimeError('could not terminate the motion process')


def running():
    return _process is not None and _process.poll() is None


def started():
    return _started


def _control_request(path: str) -> HTTPRequest:
    username, _, password = settings.MOTION_CONTROL_AUTHENTICATION.partition(':')

    return HTTPRequest(
        f'http://127.0.0.1:{settings.MOTION_CONTROL_PORT}/{path}',
        connect_timeout=_MOTION_CONTROL_TIMEOUT,
        request_timeout=_MOTION_CONTROL_TIMEOUT,
        auth_username=username or None,
        auth_password=password or None,
        auth_mode='basic',
    )


async def get_motion_detection(camera_id) -> utils.GetMotionDetectionResult:
    if _motion_detection.get(camera_id) is not None:
        return _motion_detection[camera_id]

    error: str | None = None
    motion_camera_id: int | None = camera_id_to_motion_camera_id(camera_id)
    if motion_camera_id is None:
        error = f'could not find motion camera id for camera {camera_id}'
        logging.error(error)
        return utils.GetMotionDetectionResult(None, error=error)

    request = _control_request(f'{motion_camera_id}/detection/status')
    try:
        resp = await AsyncHTTPClient().fetch(request, raise_error=False)
        if resp.error:
            error = utils.pretty_http_error(resp)

        elif resp.body.startswith(b'Bad Request'):
            error = resp.body.decode(errors='replace')

    except HTTPClientError as e:
        error = str(e)

    if error is not None:
        error = (
            f"failed to obtain motion detection status for camera {camera_id}: {error}"
        )
        logging.error(error)
        return utils.GetMotionDetectionResult(None, error=error)

    resp_body: str = resp.body.decode()
    enabled: bool = bool(resp_body.lower().count('active'))

    logging.debug(
        f"motion detection is {['disabled', 'enabled'][enabled]} for camera {camera_id}"
    )
    _motion_detection[camera_id] = utils.GetMotionDetectionResult(enabled, None)
    return _motion_detection[camera_id]


async def set_motion_detection(camera_id: int, state: str) -> str | None:
    error: str | None = None
    motion_camera_id: int | None = camera_id_to_motion_camera_id(camera_id)
    if motion_camera_id is None:
        error = f'could not find motion camera id for camera {camera_id}'
        logging.error(error)
        return error

    if state not in ('start', 'pause'):
        error = f'invalid argument {state!r}'
        logging.error(error)
        return error

    if state == 'pause':
        _motion_detected[camera_id] = False

    stat = state.removesuffix('e')
    logging.debug(f'{stat}ing motion detection for camera {camera_id}')

    request = _control_request(f'{motion_camera_id}/detection/{state}')
    try:
        resp = await AsyncHTTPClient().fetch(request, raise_error=False)
        if resp.error:
            error = utils.pretty_http_error(resp)

        elif resp.body.startswith(b'Bad Request'):
            error = resp.body.decode(errors='replace')

    except HTTPClientError as e:
        error = str(e)

    if error is not None:
        error = f'failed to {state} motion detection for camera {camera_id}: {error}'
        logging.error(error)
        return error

    logging.debug(f"successfully {stat}ed motion detection for camera {camera_id}")
    _motion_detection[camera_id] = utils.GetMotionDetectionResult(
        state == 'start', None
    )
    return None


async def trigger_action(camera_id: int, action: str) -> str | None:
    error: str | None = None
    motion_camera_id: int | None = camera_id_to_motion_camera_id(camera_id)
    if motion_camera_id is None:
        error = f'could not find motion camera id for camera {camera_id}'
        logging.error(error)
        return error

    logging.debug(f'triggering {action!r} action for camera {camera_id}')

    request = _control_request(f'{motion_camera_id}/action/{action}')
    try:
        resp = await AsyncHTTPClient().fetch(request, raise_error=False)
        if resp.error:
            error = utils.pretty_http_error(resp)

        elif resp.body.startswith(b'Bad Request'):
            error = resp.body.decode(errors='replace')

    except HTTPClientError as e:
        error = str(e)

    if error is not None:
        error = f'failed to trigger {action!r} action for camera {camera_id}: {error}'
        logging.error(error)
        return error

    logging.debug(f'successfully triggered {action!r} action for camera {camera_id}')
    return None


def is_motion_detected(camera_id):
    return _motion_detected.get(camera_id, False)


def set_motion_detected(camera_id, motion_detected):
    if motion_detected:
        logging.debug(f'marking motion detected for camera {camera_id}')

    else:
        logging.debug(f'clearing motion detected for camera {camera_id}')

    _motion_detected[camera_id] = motion_detected


def camera_id_to_motion_camera_id(camera_id):
    from motioneye import config

    # find the corresponding motion camera_id
    # (which can be different from camera_id)

    main_config = config.get_main()
    cameras = main_config.get('camera', [])

    camera_filename = f'camera-{camera_id}.conf'
    for i, camera in enumerate(cameras):
        if camera != camera_filename:
            continue

        return i + 1

    return None


def motion_camera_id_to_camera_id(motion_camera_id):
    from motioneye import config

    main_config = config.get_main()
    cameras = main_config.get('camera', [])

    try:
        return int(
            re.search(r'camera-(\d+).conf', cameras[int(motion_camera_id) - 1]).group(1)
        )

    except IndexError:
        return None


def is_motion_pre42():
    binary, version = find_motion()
    if not binary:
        return False

    return update.compare_versions(version, '4.2') < 0


def is_motion_post43():
    binary, version = find_motion()
    if not binary:
        return False

    return update.compare_versions(version, '4.4') >= 0  # 4.3.2 > 4.3


def has_h264_omx_support():
    binary, _version, codecs = mediafiles.find_ffmpeg()
    if not binary:
        return False

    return 'h264_omx' in codecs.get('h264', {}).get('encoders', set())


def has_h264_v4l2m2m_support():
    binary, _version, codecs = mediafiles.find_ffmpeg()
    if not binary:
        return False

    return 'h264_v4l2m2m' in codecs.get('h264', {}).get('encoders', set())


def has_h264_nvenc_support():
    binary, _version, codecs = mediafiles.find_ffmpeg()
    if not binary:
        return False

    return 'h264_nvenc' in codecs.get('h264', {}).get('encoders', set())


def has_h264_nvmpi_support():
    binary, _version, codecs = mediafiles.find_ffmpeg()
    if not binary:
        return False

    return 'h264_nvmpi' in codecs.get('h264', {}).get('encoders', set())


def has_hevc_nvmpi_support():
    binary, _version, codecs = mediafiles.find_ffmpeg()
    if not binary:
        return False

    return 'hevc_nvmpi' in codecs.get('hevc', {}).get('encoders', set())


def has_hevc_nvenc_support():
    binary, _version, codecs = mediafiles.find_ffmpeg()
    if not binary:
        return False

    return 'hevc_nvenc' in codecs.get('hevc', {}).get('encoders', set())


def has_h264_qsv_support():
    binary, _version, codecs = mediafiles.find_ffmpeg()
    if not binary:
        return False

    return 'h264_qsv' in codecs.get('h264', {}).get('encoders', set())


def has_hevc_qsv_support():
    binary, _version, codecs = mediafiles.find_ffmpeg()
    if not binary:
        return False

    return 'hevc_qsv' in codecs.get('hevc', {}).get('encoders', set())


def resolution_is_valid(width, height):
    # width & height must be modulo 8

    if width % 8:
        return False

    return not height % 8


async def _disable_initial_motion_detection():
    from motioneye import config

    for camera_id in config.get_camera_ids():
        camera_config = config.get_camera(camera_id)
        if not utils.is_local_motion_camera(camera_config):
            continue

        if not camera_config['@motion_detection']:
            logging.debug(f'motion detection disabled by config for camera {camera_id}')
            await set_motion_detection(camera_id, 'pause')
