# Copyright (c) 2013 Calin Crisan
# This file is part of motionEye.
#
# motionEye is free software: you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation, either version 3 of the License, or
# (at your option) any later version.
#
# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with this program.  If not, see <http://www.gnu.org/licenses/>.
from __future__ import annotations

import json
import logging
import os
import re
import signal
import socket
import time
from collections.abc import Callable
from datetime import datetime
from io import BytesIO
from urllib.parse import urlencode

import pycurl
from tornado.ioloop import IOLoop

from motioneye import config, mediafiles, meyectl, motionctl, settings, utils


class TelegramError(RuntimeError):
    def __init__(self, code, description, retry_after):
        super().__init__(f'telegram replied {code}: {description}')
        self.retry_after = retry_after


def _perform_once(c):
    reply = BytesIO()
    c.setopt(c.WRITEDATA, reply)
    try:
        c.perform()

    except pycurl.error:
        # curl would reuse a stalled HTTP/2 connection, so use new ones from now on
        c.setopt(c.FRESH_CONNECT, 1)
        raise

    code = c.getinfo(c.RESPONSE_CODE)
    try:
        result = json.loads(reply.getvalue())

    except ValueError:
        result = {}

    if code != 200 or result.get('ok') is not True:
        raise TelegramError(
            code,
            result.get('description') or 'no description',
            (result.get('parameters') or {}).get('retry_after')
            if code == 429
            else None,
        )


def _perform(c, retry):
    try:
        _perform_once(c)
        return

    except pycurl.error as e:
        # Telegram may have it once it was sent, even if the reply is lost or late
        if not retry or c.getinfo(c.SIZE_UPLOAD) > 0:
            raise

        delay = 5
        logging.warning(f'telegram request failed, retrying in {delay}s: {e}')

    except TelegramError as e:
        if not retry or not isinstance(e.retry_after, int):
            raise

        if not 0 <= e.retry_after <= 30:
            raise

        delay = e.retry_after
        logging.warning(f'{e}, retrying in {delay}s')

    time.sleep(delay)
    _perform_once(c)


def send_message(api_key, chat_id, message, files, retry=True):
    telegram_message_url = f'https://api.telegram.org/bot{api_key}/sendMessage'
    telegram_photo_url = f'https://api.telegram.org/bot{api_key}/sendPhoto'
    c = pycurl.Curl()
    c.setopt(c.POST, 1)
    c.setopt(c.CONNECTTIMEOUT, 10)
    c.setopt(c.LOW_SPEED_LIMIT, 1)
    c.setopt(c.LOW_SPEED_TIME, 60)
    c.setopt(c.URL, telegram_message_url)
    try:
        if not files:
            logging.info('no files')
            c.setopt(c.POSTFIELDS, urlencode({'chat_id': chat_id, 'text': message}))
            _perform(c, retry)
        else:
            logging.info('files present')
            failed = 0
            for f in files:
                c.setopt(c.URL, telegram_photo_url)
                # Send photos
                c.setopt(
                    c.HTTPPOST,
                    [
                        ("chat_id", chat_id),
                        ("caption", message.encode()),
                        ("photo", (c.FORM_FILE, os.fsencode(f))),
                    ],
                )
                try:
                    _perform(c, retry)

                except (RuntimeError, pycurl.error) as e:
                    logging.error(f'failed to send "{os.path.basename(f)}": {e}')
                    failed += 1

            if failed > 0:
                raise RuntimeError(f'{failed} of {len(files)} pictures not sent')

    finally:
        c.close()

    logging.debug('sending telegram')


def make_message(
    message: str,
    camera_id: int,
    moment: datetime,
    timespan: int,
    callback: Callable,
) -> None:
    camera_config = config.get_camera(camera_id)

    # we must start the IO loop for the media list subprocess polling
    io_loop = IOLoop.current()

    def on_media_files(media_files):
        io_loop.stop()

        timestamp = time.mktime(moment.timetuple())
        files: list | None = (
            media_files.result() if hasattr(media_files, 'result') else media_files
        )
        if files is None:
            logging.warning(
                f'picture listing timed out after {settings.LIST_MEDIA_TIMEOUT}s; sending '
                'notification without pictures; consider raising list_media_timeout_telegram'
            )
            files = []

        if files:
            logging.debug('got media files')
            files = [m for m in files if abs(m['timestamp'] - timestamp) < timespan]
            files.sort(key=lambda m: m['timestamp'])
            files = [
                os.path.join(camera_config['target_dir'], re.sub('^/', '', m['path']))
                for m in files
            ]
            logging.debug(f'selected {len(files)} pictures')

        format_dict = {
            'camera': camera_config['camera_name'],
            'hostname': socket.gethostname(),
            'moment': moment.strftime('%Y-%m-%d %H:%M:%S'),
        }

        format_dict['timezone'] = datetime.now().astimezone().tzname() or 'local time'

        logging.debug('creating telegram message')

        m = message % format_dict

        callback(m, files)

    if not timespan:
        on_media_files([])

        return

    logging.debug(f'waiting {timespan}s for pictures to be taken')
    time.sleep(timespan)  # give motion some time to create motion pictures

    prefix = None
    picture_filename: str = camera_config.get('picture_filename', '')
    snapshot_filename: str = camera_config.get('snapshot_filename', '')

    if (
        (picture_filename or snapshot_filename)
        and not picture_filename
        or picture_filename.startswith('%Y-%m-%d/')
        and not snapshot_filename
        or snapshot_filename.startswith('%Y-%m-%d/')
    ):
        prefix = moment.strftime('%Y-%m-%d')
        logging.debug(f'narrowing down still images path lookup to {prefix}')

    # only pictures within +/- timespan are used, see on_media_files()
    event_timestamp: float = time.mktime(moment.timetuple())
    fut = utils.cast_future(
        mediafiles.list_media(
            camera_config,
            media_type='picture',
            prefix=prefix,
            min_timestamp=event_timestamp - timespan,
            max_timestamp=event_timestamp + timespan,
        )
    )
    fut.add_done_callback(on_media_files)
    io_loop.start()

    return


def parse_options(parser, args):
    # the settings are in the camera config
    parser.description = 'Send Telegram using bot api'
    parser.add_argument('motion_camera_id', help='the id of the motion camera')
    parser.add_argument('moment', help='the moment in ISO-8601 format')
    options, extra = parser.parse_known_args(args)
    if extra:  # without their values, they may be secrets
        parser.error(
            f'{len(extra)} unexpected arguments, '
            'motionEye converts its own older commands when it starts'
        )

    try:  # not a type=, older commands have the chat id here
        options.moment = datetime.fromisoformat(options.moment)

    except ValueError:
        parser.error('moment must be in ISO-8601 format')

    return options


def main(parser, args):
    # the motion daemon overrides SIGCHLD,
    # so we must restore it here,
    # or otherwise media listing won't work
    signal.signal(signal.SIGCHLD, signal.SIG_DFL)

    options = parse_options(parser, args)
    meyectl.configure_logging('telegram')
    logging.debug(options)
    message = 'Motion has been detected by camera "%(camera)s/%(hostname)s" at %(moment)s (%(timezone)s).'

    camera_id = motionctl.motion_camera_id_to_camera_id(options.motion_camera_id)
    stored = config.get_notification_settings(camera_id, config.SENDTELEGRAM_KEYS)
    if not stored:
        logging.error(
            f'motion camera {options.motion_camera_id} has no Telegram settings'
        )
        return

    vars(options).update(stored)

    # do not wait too long for media list,
    # telegram notifications are critical
    try:
        options.timespan = int(options.timespan)
    except (TypeError, ValueError):
        options.timespan = 0

    settings.LIST_MEDIA_TIMEOUT = settings.LIST_MEDIA_TIMEOUT_TELEGRAM

    def on_message(message, files):
        try:
            logging.info(f'sending telegram : {message}')
            send_message(options.api, options.chatid, message, files or [])
            logging.info('telegram sent')

        except Exception:
            logging.exception('failed to send telegram')

        logging.debug('bye!')

    make_message(message, camera_id, options.moment, options.timespan, on_message)
